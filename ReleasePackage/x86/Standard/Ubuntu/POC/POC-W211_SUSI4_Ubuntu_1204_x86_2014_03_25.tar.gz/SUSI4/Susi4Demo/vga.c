#include "common.h"

typedef struct {
	uint32_t maxValue;
	uint32_t minValue;
	/* enableFlag						*/
	/* bit0: PWM emthod enable			*/
	/* bit1: ACPI emthod enable			*/
	/* bit2: frequency control enable	*/
	/* bit3: polarity control enable	*/
	/* bit4: backlight control enable	*/
	/* others: reserve					*/
	uint32_t enableFlag;
} VGAInfo, *PVGAInfo;

typedef struct {
	uint32_t frequencyVal;
	uint32_t polarityVal;
	uint32_t backlightVal;
	uint32_t methodVal;
	uint32_t brightnessVal;
} VGAConfig, *PVGAConfig;

enum enableRank{	
	enablePWM,
	enableACPI,
	enableFrequency,
	enablePolarity,
	enableBacklight
};

static VGAInfo info[SUSI_ID_BACKLIGHT_MAX];
static int8_t panel[SUSI_ID_BACKLIGHT_MAX];

enum methodRank{
	methodPWM,
	methodACPI
};

#define SUSIDEMO_VGA_FUNCTION_MAX 7
static int8_t func[SUSIDEMO_VGA_FUNCTION_MAX];
enum funcRank{
	funcGet,
	funcMethod,
	funcBrightness,	
	funcFrequency,
	funcPolarity,
	funcBacklight,
	funcVga
};

uint8_t vga_init(int8_t *pavailable)
{
	uint32_t status, vga_id, value;
    uint8_t index, i;

	*pavailable = 0;

	index = 0;
    for (i = 0; i < SUSI_ID_BACKLIGHT_MAX; i++)
    {
		vga_id = i;
		info[i].enableFlag = 0;

		status = SusiVgaGetCaps(vga_id, SUSI_ID_VGA_BRIGHTNESS_MAXIMUM, &info[i].maxValue);
        if (status == SUSI_STATUS_SUCCESS && info[i].maxValue > 0)
			info[index].enableFlag |= (1 << enablePWM);

		if ((info[index].enableFlag & (1 << enablePWM)) != 0)
		{
			status = SusiVgaGetCaps(vga_id, SUSI_ID_VGA_BRIGHTNESS_MINIMUM, &info[i].minValue);
			if (status != SUSI_STATUS_SUCCESS)
			{
				//printf("SusiVgaGetCaps() failed. (0x%08X)\n", status);
				info[i].enableFlag &= ~(1 << enablePWM);
				//return 1;
			}
		}

		status = SusiVgaGetBacklightLevel(vga_id, &value);
        if (status == SUSI_STATUS_SUCCESS)
			info[i].enableFlag |= (1 << enableACPI);

		if (info[i].enableFlag == 0)
			continue;

		status = SusiVgaGetFrequency(vga_id, &value);
		if (status == SUSI_STATUS_SUCCESS)
			info[i].enableFlag |= (1 << enableFrequency);

		status = SusiVgaGetPolarity(vga_id, &value);
		if (status == SUSI_STATUS_SUCCESS)
			info[i].enableFlag |= (1 << enablePolarity);

		status = SusiVgaGetBacklightEnable(vga_id, &value);
		if (status == SUSI_STATUS_SUCCESS)
			info[i].enableFlag |= (1 << enableBacklight);

		panel[index] = i;
		index++;
    }

	if (index == 0)
		return 0;

	for (i = index; i < SUSI_ID_BACKLIGHT_MAX; i++)
		panel[i] = -1;

	*pavailable = 1;

	return 0;
}

static uint8_t title(uint8_t iPanel)
{
	printf("**********************************************\n");
	printf("**               SUSI4.0 demo               **\n");
	printf("**********************************************\n");

	if (iPanel >= SUSI_ID_BACKLIGHT_MAX)
	{
		printf("ERROR: The flat panel is not exist.\n");
		return 1;
	}

	printf("\nVGA: Flat Panel %d\n\n", iPanel + 1);

	return 0;
}

static uint8_t brightness_method_init(uint8_t iPanel, uint32_t *pvalue)
{
	if (iPanel >= SUSI_ID_BACKLIGHT_MAX)
	{
		printf("ERROR: The flat panel is not exist.\n");
		return 1;
	}

	if ((info[iPanel].enableFlag & (1 << enablePWM)) != 0)
	{
		*pvalue = methodPWM;
	}
	else if ((info[iPanel].enableFlag & (1 << enableACPI)) != 0)
	{
		*pvalue = methodACPI;
	}
	else
	{
		printf("ERROR: No brightness method is supported.\n");
		return 1;
	}

	return 0;
}

static uint8_t select_panel(uint8_t *piPanel)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("\nFlat Panel:\n");
	for (i = 0; i < SUSI_ID_BACKLIGHT_MAX && panel[i] > -1; i++)
	{
		if (panel[i] == *piPanel)
			printf("%u) [Flat Panel %u]\n", i, panel[i] + 1);
		else
			printf("%u) Flat Panel %u\n", i, panel[i] + 1);
	}

	if (i == 1)
	{
		*piPanel = panel[0];
		printf("Only Flat Panel %u is available.\n", *piPanel + 1);
		printf("\nPress ENTER to continue. ");
		wait_enter();
		return 0;
	}

	tmp_u32 = 0;
	do {		
		printf("\nEnter your choice (0 to %u): ", i - 1);
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*piPanel = panel[tmp_u32];

	return 0;
}

static uint8_t get_frequency(uint32_t vga_id, uint32_t *pvalue)
{
	uint32_t status;

    status = SusiVgaGetFrequency(vga_id, pvalue);
	if (status != SUSI_STATUS_SUCCESS)
		return 1;

	return 0;
}

static uint8_t set_frequency(uint32_t vga_id, uint32_t orgVal)
{
	uint32_t status, setVal;

	setVal = 0;
	do {
		printf("\nFrequency (Hz): %u -> ", orgVal);
	} while (input_uint(&setVal, 10, 0xFFFF, 1) != 0);

    status = SusiVgaSetFrequency(vga_id, setVal);
	if (status != SUSI_STATUS_SUCCESS)
		return 1;

	return 0;
}

static uint8_t get_polarity(uint32_t vga_id, uint32_t *pvalue)
{
	uint32_t status;

    status = SusiVgaGetPolarity(vga_id, pvalue);
    if (status != SUSI_STATUS_SUCCESS)
		return 1;

	return 0;
}

static uint8_t change_polarity(uint32_t vga_id, uint32_t orgVal)
{
	uint32_t status;

	if (orgVal == SUSI_BACKLIGHT_POLARITY_OFF)
		status = SusiVgaSetPolarity(vga_id, SUSI_BACKLIGHT_POLARITY_ON);
	else
		status = SusiVgaSetPolarity(vga_id, SUSI_BACKLIGHT_POLARITY_OFF);
    
    if (status != SUSI_STATUS_SUCCESS)
    {
		printf("SusiVgaSetPolarity() failed. (0x%08X)\n", status);
		return 1;
    }

	return 0;
}

static uint8_t get_backlight(uint32_t vga_id, uint32_t *pvalue)
{
	uint32_t status;

	status = SusiVgaGetBacklightEnable(vga_id, pvalue);
	if (status != SUSI_STATUS_SUCCESS)
		return 1;

	return 0;
}

static uint8_t change_backlight(uint32_t vga_id, uint32_t orgVal)
{
	uint32_t status;

	if (orgVal == SUSI_BACKLIGHT_SET_OFF)
		status = SusiVgaSetBacklightEnable(vga_id, SUSI_BACKLIGHT_SET_ON);
	else
		status = SusiVgaSetBacklightEnable(vga_id, SUSI_BACKLIGHT_SET_OFF);    
	
    if (status != SUSI_STATUS_SUCCESS)
    {
		printf("SusiVgaSetBacklightEnable() failed. (0x%08X)\n", status);
		return 1;
    }

	return 0;
}

static uint8_t change_method(uint8_t iPanel, uint32_t *pvalue)
{
	if (iPanel >= SUSI_ID_BACKLIGHT_MAX)
	{
		printf("Unknow device.\n");
		return 1;
	}

	if (*pvalue == methodPWM)
	{
		if ((info[iPanel].enableFlag & (1 << enableACPI)) != 0)
		{
			*pvalue = methodACPI;
		}
		else
		{
			printf("The flat panel supports PWM method only.\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}
	else if (*pvalue == methodACPI)
	{
		if ((info[iPanel].enableFlag & (1 << enablePWM)) != 0)
		{
			*pvalue = methodPWM;
		}
		else
		{
			printf("The flat panel supports ACPI method only.\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}
	else
	{
		return brightness_method_init(iPanel, pvalue);
	}

	return 0;
}

static uint8_t get_brightness(uint32_t vga_id, uint32_t methodVal, uint32_t *pvalue)
{
	uint32_t status;

	switch (methodVal)
	{
	case methodPWM:
		status = SusiVgaGetBacklightBrightness(vga_id, pvalue);
        if (status != SUSI_STATUS_SUCCESS)
		{
			printf("SusiVgaGetBacklightBrightness() failed. (0x%08X)\n", status);
			return 1;
		}
		break;

	case methodACPI:
		status = SusiVgaGetBacklightLevel(vga_id, pvalue);
		if (status != SUSI_STATUS_SUCCESS)
		{
			printf("SusiVgaGetBacklightLevel() failed. (0x%08X)\n", status);
			return 1;
		}
		break;

	default:
		printf("Unknow method.\n");
		return 1;
	}

	return 0;
}

static uint8_t set_brightness(uint32_t vga_id, VGAInfo vgaInfo, uint32_t methodVal)
{
	uint32_t status, setVal;

	switch (methodVal)
	{
	case methodPWM:
		if ((vgaInfo.enableFlag & (1 << enablePWM)) == 0)
		{
			printf("PWM method is unsupported.\n");
			return 1;
		}

		do {
			printf("\nBrightness value (%u to %u): ", vgaInfo.minValue, vgaInfo.maxValue);
		} while (input_uint(&setVal, 10, vgaInfo.maxValue, vgaInfo.minValue) != 0);

		status = SusiVgaSetBacklightBrightness(vga_id, setVal);
        if (status != SUSI_STATUS_SUCCESS)
		{
			printf("SusiVgaSetBacklightBrightness() failed. (0x%08X)\n", status);
			return 1;
		}
		break;

	case methodACPI:
		if ((vgaInfo.enableFlag & (1 << enableACPI)) == 0)
		{
			printf("ACPI method is unsupported.\n");
			return 1;
		}

		do {
			printf("\nBrightness level (%u ~ %u): ", SUSI_BACKLIGHT_LEVEL_MINIMUM, SUSI_BACKLIGHT_LEVEL_MAXIMUM);
		} while (input_uint(&setVal, 10, SUSI_BACKLIGHT_LEVEL_MAXIMUM, SUSI_BACKLIGHT_LEVEL_MINIMUM) != 0);

		status = SusiVgaSetBacklightLevel(vga_id, setVal);
		if (status != SUSI_STATUS_SUCCESS)
		{
			printf("SusiVgaSetBacklightLevel() failed. (0x%08X)\n", status);
			return 1;
		}
		break;

	default:
		printf("Unknown choice!\n");
		return 1;
	}

	return 0;
}

static uint8_t get_config(uint32_t vga_id, uint32_t flag, PVGAConfig pconfig)
{
	if ((flag & ((1 << enablePWM) | (1 << enableACPI))) != 0)
	{
		if (get_brightness(vga_id, pconfig->methodVal, &pconfig->brightnessVal) != 0)
			return 1;
	}

	if ((flag & (1 << enableFrequency)) != 0)
	{
		if (get_frequency(vga_id, &pconfig->frequencyVal) != 0)
			return 1;
	}

	if ((flag & (1 << enablePolarity)) != 0)
	{
		if (get_polarity(vga_id, &pconfig->polarityVal) != 0)
			return 1;
	}

	if ((flag & (1 << enableBacklight)) != 0)
	{
		if (get_backlight(vga_id, &pconfig->backlightVal) != 0)
			return 1;
	}

	return 0;
}

static uint8_t show_menu(uint8_t iPanel, PVGAConfig pconfig)
{
	uint8_t i;

	printf("0) Back to Main menu\n");
	printf("1) Select flat panel\n");
	func[0] = funcVga;	

	i = 1;

	if ((info[iPanel].enableFlag & ((1 << enablePWM) | (1 << enableACPI))) != 0)
	{
		printf("%u) Brightness method: ", i + 1);

		if ((info[iPanel].enableFlag & (1 << enablePWM)) != 0)
		{
			if (pconfig->methodVal == methodPWM)
				printf("[PWM]");
			else
				printf(" PWM ");
		}

		if ((info[iPanel].enableFlag & (1 << enableACPI)) != 0)
		{
			if (pconfig->methodVal == methodACPI)
				printf("/[ACPI]");
			else
				printf("/ ACPI");
		}

		printf("\n");
		func[i] = funcMethod;
		i++;
	}
	else
	{
		printf("ERROR: No brightness method is supported.\n");
		return 1;
	}
	

	if (pconfig->methodVal == methodPWM)
	{
		printf("%u) Brightness value (%u to %u): %u\n", i + 1, info[iPanel].minValue, info[iPanel].maxValue, pconfig->brightnessVal);
		func[i] = funcBrightness;
		i++;
	}
	else if (pconfig->methodVal == methodACPI)
	{
		printf("%u) Brightness level: %u / %u\n", i + 1, pconfig->brightnessVal - SUSI_BACKLIGHT_LEVEL_MINIMUM, SUSI_BACKLIGHT_LEVEL_MAXIMUM - SUSI_BACKLIGHT_LEVEL_MINIMUM);
		func[i] = funcBrightness;
		i++;
	}

	if ((info[iPanel].enableFlag & (1 << enableFrequency)) != 0)
	{
		printf("%u) Frequency: %u\n", i + 1, pconfig->frequencyVal);
		func[i] = funcFrequency;
		i++;
	}

	if ((info[iPanel].enableFlag & (1 << enablePolarity)) != 0)
	{
		printf("%u) Polarity: ", i + 1);
		pconfig->polarityVal == SUSI_BACKLIGHT_POLARITY_ON ? printf("[Yes]/ No\n") : printf(" Yes /[No]\n");
		func[i] = funcPolarity;
		i++;
	}

	if ((info[iPanel].enableFlag & (1 << enableBacklight)) != 0)
	{
		printf("%u) Backlight: ", i + 1);
		pconfig->backlightVal == SUSI_BACKLIGHT_SET_ON ? printf("[On]/ Off\n") : printf(" On /[Off]\n");
		func[i] = funcBacklight;
		i++;
	}

	printf("%u) Get/Refresh all values\n", i + 1);
	func[i] = funcGet;	
	i++;

	printf("\nSelect the item you want to set: ");

	while (i < SUSIDEMO_VGA_FUNCTION_MAX)
	{
		func[i] = -1;
		i++;
	}

	return 0;
}



uint8_t vga_main(void)
{
	int32_t op;
	uint32_t vga_id;
	uint8_t result, iPanel;
	VGAConfig config;

	result = 0;

	iPanel = panel[0];
	vga_id = iPanel;

	while (brightness_method_init(iPanel, &config.methodVal) != 0)
	{
		iPanel++;
		if (iPanel >= SUSI_ID_BACKLIGHT_MAX)
			return 1;
	}

	for (;;)
	{
		clr_screen();
		if (title(iPanel) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (get_config(vga_id, info[iPanel].enableFlag, &config) != 0)
		{			
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (show_menu(iPanel, &config) != 0)
		{			
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op == 0)
		{
			clr_screen();
			break;
		}

		if (op < 1 || op > SUSIDEMO_VGA_FUNCTION_MAX)
		{
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			continue;
		}

		switch (func[op - 1])
		{
		case funcVga:
			result = select_panel(&iPanel);
			if (result == 0)
			{
				result = brightness_method_init(iPanel, &config.methodVal);
				vga_id = iPanel;
			}
			break;

		case funcMethod:
			result = change_method(iPanel, &config.methodVal);
			break;

		case funcBrightness:
			result = set_brightness(vga_id, info[iPanel], config.methodVal);
			break;

		case funcFrequency:
			result = set_frequency(vga_id, config.frequencyVal);
			break;

		case funcPolarity:
			result = change_polarity(vga_id, config.polarityVal);
			break;

		case funcBacklight:
			result = change_backlight(vga_id, config.backlightVal);
			break;

		case funcGet:
			continue;

		default:
			result = 1;
			printf("Unknown choice!\n");			
			break;
		}

		if (result != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}

	clr_screen();

	return 0;
}
