#!/usr/bin/env bash 
 
 clear
 
   sudo ./Susi_Jetson_Service 
 
 
