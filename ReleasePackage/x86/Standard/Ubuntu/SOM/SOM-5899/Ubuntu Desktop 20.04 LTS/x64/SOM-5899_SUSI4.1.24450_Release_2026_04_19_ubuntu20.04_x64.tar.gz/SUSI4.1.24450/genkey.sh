#!/bin/bash

echo "*****************************************************************"
echo "*                SOFTWARE SUSI LICENSE AGREEMENT                *"
echo "* Please carefully read the terms and conditions in license.rtf.*"
echo "* Do you agree with above patent declaration?                   *"
echo "*****************************************************************"
echo "  [Y] Yes, I agree.  [N] No, I don't agree."
read ans
if [ ${ans} != "Y" -a ${ans} != "y" ];then
	exit 1
fi

if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
else
    echo "Unknown OS"
    exit 1
fi

# Install sign tool
case "$OS" in
    ubuntu|debian)
        apt -y install mokutil openssl
        ;;
    centos|rhel)
        yum install -y mokutil openssl
        ;;
    fedora)
        dnf install -y mokutil openssl
        ;;
    suse|opensuse|sled|sles)
        zypper install -y mokutil openssl
        ;;
    *)
        echo "Please install mokutil and openssl"
        exit 1
        ;;
esac

# Generate x509 configuration file
cat >> /tmp/x509.conf <<EOF
[ req ]
default_bits = 4096
distinguished_name = req_distinguished_name
prompt = no
string_mask = utf8only
x509_extensions = extensions

[ req_distinguished_name ]
O = Manufacturer
CN = SUSI
emailAddress = user@manufacturer.com

[ extensions ]
extendedKeyUsage = codeSigning
basicConstraints = critical,CA:FALSE
keyUsage = digitalSignature
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid
EOF


# Generate custom keys with openssl
sudo openssl req -x509 -new -nodes -utf8 -sha256 -days 3650 -batch -config /tmp/x509.conf -outform DER -out /home/pubkey.der -keyout /home/priv.key

# Set more restrictive permisions as these are private keys
chmod a+x /home/pubkey.der
chmod a+x /home/priv.key

# Add the key to the trusted keys database
sudo mokutil --import /home/pubkey.der

while [ true ]; do
read -n 1 -p "Press any key to reboot..." key
if [ true ] ; then
reboot ;
fi done
