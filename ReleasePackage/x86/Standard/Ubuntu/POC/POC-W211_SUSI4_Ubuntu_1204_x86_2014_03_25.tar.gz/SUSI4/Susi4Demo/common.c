#include "common.h"

uint8_t input_uint(uint32_t *psetVal, uint8_t base, uint32_t maxVal, uint32_t minVal)
{
	int32_t ret;

	if (psetVal == NULL)
		return 1;

	switch (base)
	{
	case 8:
		ret = SCANF_IN("%o", psetVal);
		break;
	case 10:
		ret = SCANF_IN("%u", psetVal);
		break;	
	case 16:
		ret = SCANF_IN("%x", psetVal);
		break;
	default:
		return 1;
	}

	wait_enter();

	if (ret <= 0)
		return 1;

	if (*psetVal > maxVal || *psetVal < minVal)
		return 1;

	return 0;
}

uint8_t input_byte_sequence(uint8_t *pbuffer, uint32_t length, uint32_t *endNumber, uint8_t base, uint8_t maxVal, uint8_t minVal)
{
	int32_t ret;
	uint32_t tmp_u32, i;

	if (endNumber > 0)
		*endNumber = 0;

	if (pbuffer == 0)
		return 1;

	ret = 0;
	for (i = 0; i < length; i++)
	{
		switch (base)
		{
		case 8:
			ret = SCANF_IN("%o", &tmp_u32);
			break;
		case 10:
			ret = SCANF_IN("%u", &tmp_u32);
			break;	
		case 16:
			ret = SCANF_IN("%x", &tmp_u32);
			break;
		default:			
			return 1;
		}

		if (ret <= 0)
			break;

		if (tmp_u32 > maxVal || tmp_u32 < minVal)
		{
			ret = -2;
			break;
		}

		pbuffer[i] = (uint8_t)tmp_u32;
	}

	if (i > 0)
		wait_enter();

	if (ret < 0)
	{
		if (endNumber > 0)
			*endNumber = i;

		return 1;
	}
	
	if (endNumber > 0)
		*endNumber = length;

	return 0;
}

void wait_enter(void)
{
    int c;
	while ((c = getchar()) != '\n' && c != EOF);
}

int clr_screen(void)
{
	return system(CLRSCR);
}