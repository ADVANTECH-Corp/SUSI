#!/usr/bin/env bash 
 


 currentDir=$1
 

func_install_serviceA_all(){

#sudo systemctl stop susi_api_server.service


# service output dir : create
sudo mkdir -p /etc/Advantech/susi/service/

# run service dir (at first)
sudo mkdir -p /opt/Advantech/susi/service
sudo cp $currentDir/Susi_Jetson_Service $currentDir/exeSusiService.sh /opt/Advantech/susi/service


sudo cp $currentDir/susi_api_server.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable susi_api_server
sudo systemctl start susi_api_server


}



func_install_serviceA_all

















