#include "common.h"
#include "version.h"

#define SUSIDEMO_MAIN_PAGE_MAX 10

/* 1: available; 0: unavailable */
static int8_t available[SUSIDEMO_MAIN_PAGE_MAX];

/* page[0]: the 1st available page index */
/* page[1]: the 2st available page index */
/* ...                                   */
/* else page[i] = -1                     */
static int8_t page[SUSIDEMO_MAIN_PAGE_MAX];

static const char *pageStr[] = {
	"Watch Dog",
	"HWM",
	"Smart Fan",
	"GPIO",
	"VGA",
	"SMBus",
	"I2C",
	"Storage",
	"Thermal Protection",
	"Information"
};

enum pageRank{
	wdog,
	hwm,
	smartfan,
	gpio,
	vga,
	smb,
	iic,
	storage,
	thermalprotection,
	info
};

static void main_title(void)
{
	printf("**********************************************\n");
	printf("**               SUSI4.0 demo               **\n");
	printf("**********************************************\n");
	printf("\nMain (demo version : %d.%d.%d.%d)\n\n", VER_MAJOR, VER_MINOR, VER_BUILD, VER_FIX);
}

/* returns 0 if platform infomation is correctly obtained; otherwise, returns 1. */
static int get_available(void)
{
	uint8_t index, i;

	wdog_init(&available[wdog]);
	hwm_init(&available[hwm]);
	smartfan_init(&available[smartfan]);
	gpio_init(&available[gpio]);
	vga_init(&available[vga]);
	smb_init(&available[smb]);
	iic_init(&available[iic]);
	storage_init(&available[storage]);
	thermalprotection_init(&available[thermalprotection]);
	info_init(&available[info]);

	index = 0;
	for (i = 0; i < SUSIDEMO_MAIN_PAGE_MAX; i++)
	{
		if (available[i] == 1)
		{
			page[index] = i;
			index++;
		}
	}

	if (index == 0)
	{
		printf("No page is available.\n");
		return 1;
	}

	for (i = index; i < SUSIDEMO_MAIN_PAGE_MAX; i++)
		page[i] = -1;

	return 0;
}

static void show_menu(void)
{
	uint8_t i;

	printf("0) Terminate this program\n");
	
	for (i = 0; i < SUSIDEMO_MAIN_PAGE_MAX; i++)
	{
		if (page[i] >= 0)
			printf("%u) %s\n", i + 1, pageStr[page[i]]);
		else
			break;
	}
	
	printf("\nEnter your choice: ");
}

int main(void)
{
	uint32_t status;
	uint8_t result;
	int32_t op;

	status = SusiLibInitialize();

	if (status != SUSI_STATUS_SUCCESS)
	{
		printf("SusiLibInitialize() failed. (0x%08X)\n", status);
		printf("Exit the program...\n");
		return 1;
	}	

	if (get_available() != 0)
	{
		printf("Exit the program...\n");
		SusiLibUninitialize();
		return 1;
	}

	for (;;)
	{
		clr_screen();
		main_title();
		show_menu();

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op == 0)
		{
			printf("Exit the program...\n");
			break;
		}

		clr_screen();

		if (op < 1 || op > SUSIDEMO_MAIN_PAGE_MAX)
		{
			printf("\nUnknown choice!\n\n");
			op = -1;
			continue;
		}

		switch (page[op - 1])
		{
		case wdog:
			result = wdog_main();
			break;
		case hwm:
			result = hwm_main();
			break;
		case smartfan:
			result = smartfan_main();
			break;
		case gpio:
			result = gpio_main();
			break;
		case vga:
			result = vga_main();
			break;
		case smb:
			result = smb_main();
			break;
		case iic:
			result = iic_main();
			break;
		case storage:
			result = storage_main();
			break;
		case thermalprotection:
			result = thermalprotection_main();
			break;
		case info:
			break;
		default:			
			op = -1;
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			continue;
		}

		if (result != 0)
		{
			printf("\nLibrary returns with error.\n");
			printf("Exit the program...\n");
			SusiLibUninitialize();
			return 1;
		}
	}

	status = SusiLibUninitialize();
	if (status != SUSI_STATUS_SUCCESS)
	{
		printf("SusiLibUninitialize() failed. (%8X)\n", status);
		return 1;
	}

	return 0;
}
