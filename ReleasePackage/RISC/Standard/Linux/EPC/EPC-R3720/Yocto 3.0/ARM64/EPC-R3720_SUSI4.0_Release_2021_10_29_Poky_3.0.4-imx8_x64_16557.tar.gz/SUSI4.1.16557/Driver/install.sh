#!/bin/bash

read -p "Press [1] to install or [2] to uninstall: " USERINPUT

if [ ${USERINPUT} == "1" ]; then
  rm -rf /usr/lib/libSUSI-4.00.so*
  rm -rf /usr/lib/Advantech/Susi/ini
  ldconfig
  mkdir -p /usr/lib/Advantech/Susi/ini
  cp -axr ini/*.ini /usr/lib/Advantech/Susi/ini
  cp -axr lib*.* /usr/lib/
  ldconfig
  cp -axr ../Susi4Demo/susidemo4 /usr/bin/
  echo "install done"
elif [ ${USERINPUT} == "2" ]; then
  rm -rf /usr/lib/libSUSI-4.00.so*
  rm -rf /usr/lib/Advantech/Susi/ini
  rm /usr/bin/susidemo4
  ldconfig
  echo "uninstall done"
fi
