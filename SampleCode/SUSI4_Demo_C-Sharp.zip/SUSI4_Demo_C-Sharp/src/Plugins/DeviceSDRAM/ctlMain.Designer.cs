﻿namespace Susi4.Plugin
{
	partial class ctlMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label17 = new System.Windows.Forms.Label();
            this.label_DRAMManufacture = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label_ModuleManufacture = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label_WP = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label_Temperature = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_WeekYear = new System.Windows.Forms.Label();
            this.label_Bank = new System.Windows.Forms.Label();
            this.label_Vol = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label_Rank = new System.Windows.Forms.Label();
            this.label_Speed = new System.Windows.Forms.Label();
            this.label_Size = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_Module = new System.Windows.Forms.Label();
            this.label_PartNum = new System.Windows.Forms.Label();
            this.label_Memory = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label_Spe = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(19, 210);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(104, 12);
            this.label17.TabIndex = 58;
            this.label17.Text = "DRAM Manufacture:";
            // 
            // label_DRAMManufacture
            // 
            this.label_DRAMManufacture.AutoSize = true;
            this.label_DRAMManufacture.Location = new System.Drawing.Point(129, 210);
            this.label_DRAMManufacture.Name = "label_DRAMManufacture";
            this.label_DRAMManufacture.Size = new System.Drawing.Size(13, 12);
            this.label_DRAMManufacture.TabIndex = 59;
            this.label_DRAMManufacture.Text = "--";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 191);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(106, 12);
            this.label12.TabIndex = 55;
            this.label12.Text = "Module Manufacture:";
            // 
            // label_ModuleManufacture
            // 
            this.label_ModuleManufacture.AutoSize = true;
            this.label_ModuleManufacture.Location = new System.Drawing.Point(129, 191);
            this.label_ModuleManufacture.Name = "label_ModuleManufacture";
            this.label_ModuleManufacture.Size = new System.Drawing.Size(13, 12);
            this.label_ModuleManufacture.TabIndex = 56;
            this.label_ModuleManufacture.Text = "--";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 12);
            this.label7.TabIndex = 51;
            this.label7.Text = "Write Protection:";
            // 
            // label_WP
            // 
            this.label_WP.AutoSize = true;
            this.label_WP.Location = new System.Drawing.Point(129, 244);
            this.label_WP.Name = "label_WP";
            this.label_WP.Size = new System.Drawing.Size(13, 12);
            this.label_WP.TabIndex = 52;
            this.label_WP.Text = "--";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(19, 173);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 12);
            this.label16.TabIndex = 46;
            this.label16.Text = "Temperture:";
            // 
            // label_Temperature
            // 
            this.label_Temperature.AutoSize = true;
            this.label_Temperature.Location = new System.Drawing.Point(129, 173);
            this.label_Temperature.Name = "label_Temperature";
            this.label_Temperature.Size = new System.Drawing.Size(13, 12);
            this.label_Temperature.TabIndex = 47;
            this.label_Temperature.Text = "--";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 12);
            this.label10.TabIndex = 40;
            this.label10.Text = "Week-Year:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 12);
            this.label11.TabIndex = 41;
            this.label11.Text = "Bank:";
            // 
            // label_WeekYear
            // 
            this.label_WeekYear.AutoSize = true;
            this.label_WeekYear.Location = new System.Drawing.Point(129, 103);
            this.label_WeekYear.Name = "label_WeekYear";
            this.label_WeekYear.Size = new System.Drawing.Size(13, 12);
            this.label_WeekYear.TabIndex = 42;
            this.label_WeekYear.Text = "--";
            // 
            // label_Bank
            // 
            this.label_Bank.AutoSize = true;
            this.label_Bank.Location = new System.Drawing.Point(129, 137);
            this.label_Bank.Name = "label_Bank";
            this.label_Bank.Size = new System.Drawing.Size(13, 12);
            this.label_Bank.TabIndex = 43;
            this.label_Bank.Text = "--";
            // 
            // label_Vol
            // 
            this.label_Vol.AutoSize = true;
            this.label_Vol.Location = new System.Drawing.Point(129, 155);
            this.label_Vol.Name = "label_Vol";
            this.label_Vol.Size = new System.Drawing.Size(13, 12);
            this.label_Vol.TabIndex = 44;
            this.label_Vol.Text = "--";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 155);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 12);
            this.label15.TabIndex = 45;
            this.label15.Text = "Voltage:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 12);
            this.label4.TabIndex = 34;
            this.label4.Text = "Rank:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 12);
            this.label5.TabIndex = 35;
            this.label5.Text = "Memory Speed:";
            // 
            // label_Rank
            // 
            this.label_Rank.AutoSize = true;
            this.label_Rank.Location = new System.Drawing.Point(129, 119);
            this.label_Rank.Name = "label_Rank";
            this.label_Rank.Size = new System.Drawing.Size(13, 12);
            this.label_Rank.TabIndex = 36;
            this.label_Rank.Text = "--";
            // 
            // label_Speed
            // 
            this.label_Speed.AutoSize = true;
            this.label_Speed.Location = new System.Drawing.Point(129, 49);
            this.label_Speed.Name = "label_Speed";
            this.label_Speed.Size = new System.Drawing.Size(13, 12);
            this.label_Speed.TabIndex = 37;
            this.label_Speed.Text = "--";
            // 
            // label_Size
            // 
            this.label_Size.AutoSize = true;
            this.label_Size.Location = new System.Drawing.Point(129, 85);
            this.label_Size.Name = "label_Size";
            this.label_Size.Size = new System.Drawing.Size(13, 12);
            this.label_Size.TabIndex = 38;
            this.label_Size.Text = "--";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 12);
            this.label9.TabIndex = 39;
            this.label9.Text = "Module Size:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 32;
            this.label3.Text = "Module Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 12);
            this.label2.TabIndex = 31;
            this.label2.Text = "PartNumber:";
            // 
            // label_Module
            // 
            this.label_Module.AutoSize = true;
            this.label_Module.Location = new System.Drawing.Point(129, 67);
            this.label_Module.Name = "label_Module";
            this.label_Module.Size = new System.Drawing.Size(13, 12);
            this.label_Module.TabIndex = 30;
            this.label_Module.Text = "--";
            // 
            // label_PartNum
            // 
            this.label_PartNum.AutoSize = true;
            this.label_PartNum.Location = new System.Drawing.Point(129, 15);
            this.label_PartNum.Name = "label_PartNum";
            this.label_PartNum.Size = new System.Drawing.Size(13, 12);
            this.label_PartNum.TabIndex = 29;
            this.label_PartNum.Text = "--";
            // 
            // label_Memory
            // 
            this.label_Memory.AutoSize = true;
            this.label_Memory.Location = new System.Drawing.Point(129, 31);
            this.label_Memory.Name = "label_Memory";
            this.label_Memory.Size = new System.Drawing.Size(13, 12);
            this.label_Memory.TabIndex = 33;
            this.label_Memory.Text = "--";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 12);
            this.label1.TabIndex = 28;
            this.label1.Text = "Memory Type:";
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(20, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(431, 34);
            this.groupBox1.TabIndex = 63;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Socket No.";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label_Spe);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label_Memory);
            this.groupBox2.Controls.Add(this.label_DRAMManufacture);
            this.groupBox2.Controls.Add(this.label_PartNum);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label_Module);
            this.groupBox2.Controls.Add(this.label_ModuleManufacture);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label_WP);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label_Size);
            this.groupBox2.Controls.Add(this.label_Speed);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label_Rank);
            this.groupBox2.Controls.Add(this.label_Temperature);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label_WeekYear);
            this.groupBox2.Controls.Add(this.label_Vol);
            this.groupBox2.Controls.Add(this.label_Bank);
            this.groupBox2.Location = new System.Drawing.Point(20, 35);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(431, 273);
            this.groupBox2.TabIndex = 64;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "General Information";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 12);
            this.label6.TabIndex = 60;
            this.label6.Text = "Specific Data:";
            // 
            // label_Spe
            // 
            this.label_Spe.AutoSize = true;
            this.label_Spe.Location = new System.Drawing.Point(129, 227);
            this.label_Spe.Name = "label_Spe";
            this.label_Spe.Size = new System.Drawing.Size(13, 12);
            this.label_Spe.TabIndex = 61;
            this.label_Spe.Text = "--";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // ctlMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ctlMain";
            this.Size = new System.Drawing.Size(544, 425);
            this.Load += new System.EventHandler(this.Main_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label_DRAMManufacture;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label_ModuleManufacture;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_WP;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label_Temperature;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_WeekYear;
        private System.Windows.Forms.Label label_Bank;
        private System.Windows.Forms.Label label_Vol;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label_Rank;
        private System.Windows.Forms.Label label_Speed;
        private System.Windows.Forms.Label label_Size;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_Module;
        private System.Windows.Forms.Label label_PartNum;
        private System.Windows.Forms.Label label_Memory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_Spe;
    }
}

