Linux SUSI driver

How to install SUSI driver & run demo AP
User Mode:
1.$ tar zxf release_user_file.tar.gz
2.$ sudo make           //Command in Driver folder. Installer will copy all libSUSI-4.00.* to /usr/lib
3.$ sudo ./susidemo4    //Command in SusiDemo folder. Run demo AP
Kernel Mode:
1.$ tar zxf release_kernel_file.tar.gz
2.$ sudo make           //Command in Driver folder. Installer will copy all libSUSI-4.00.* to /usr/lib
3.$ sudo make load      //Command in Driver folder. Installer will load module Susi4
4.$ ./susidemo4         //Command in SusiDemo folder. Run demo AP

complie sample sources AP
1.*.c are the sample sources.
2.make sure all libSUSI-4.00.* in your sample sources folder.
3.you can refer to Makefile, then use "make" to complie it.
