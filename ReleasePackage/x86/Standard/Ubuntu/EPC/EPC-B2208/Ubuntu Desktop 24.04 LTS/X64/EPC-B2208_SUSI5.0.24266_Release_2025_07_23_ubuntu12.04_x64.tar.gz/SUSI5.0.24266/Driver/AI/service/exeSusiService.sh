#!/usr/bin/env bash
clear
./Susi_X86_64_Service
