#include "common.h"

static int host[SUSI_SMBUS_MAX_DEVICE];
static const char *hostStr[] = {
	"External",
	"OEM0",
	"OEM1",
	"OEM2",
	"OEM3"
};
enum hostRank{
	hostExternal,
	hostOEM0,
	hostOEM1,
	hostOEM2,
	hostOEM3
};

#define SUSI_PROTOCAL_TYPE_MAX 6
const char *protocalStr[] = {
	"Quick",
	"Byte",
	"Byte Data",
	"Word Data",
	"Block",
	"I2C Block"
};
enum protocalRank{
	protQuick,
	protByte,
	protByteData,
	protWordData,
	protBlock,
	protI2CBlock
};

#define SUSIDEMO_SMB_FUNCTION_MAX	4
static int8_t func[SUSIDEMO_SMB_FUNCTION_MAX];
enum funcRank{
	funcHost,
	funcProbe,
	funcRead,
	funcWrite	
};

typedef struct {
	uint8_t addr;
	uint8_t cmd;
	uint8_t protocal;
	uint32_t length;
} SMBParameter, *PSMBParameter;

#define SUSIDEMO_SMB_PARAMETER_MAX	5
static int8_t para[SUSIDEMO_SMB_PARAMETER_MAX];
enum paraRank{
	paraProtocal,
	paraAddr,
	paraCmd,
	paraLen,
	paraRun
};

uint8_t smb_init(int8_t *pavailable)
{
	uint32_t status, supFlag;
	uint8_t index, i;

	*pavailable = 0;

	status = SusiBoardGetValue(SUSI_ID_SMBUS_SUPPORTED, &supFlag);

	if (status != SUSI_STATUS_SUCCESS)
	{
		printf("SusiBoardGetValue() failed. (0x%08X)\n", status);
		*pavailable = 0;
		return 1;
	}

	if (supFlag == 0)
	{
		*pavailable = 0;
		return 0;
	}

	index = 0;
    for (i = 0; i < SUSI_SMBUS_MAX_DEVICE; i++)
    {
        if ((supFlag & (1 << i)) > 0)
        {
			host[index] = i;
			index++;
        }
    }

	for (i = index; i < SUSI_SMBUS_MAX_DEVICE; i++)
		host[i] = -1;

	*pavailable = 1;

	for (i = 0; i < SUSIDEMO_SMB_FUNCTION_MAX; i++)
		func[i] = i;

	return 0;
}

static uint8_t title(uint8_t iHost)
{
	printf("**********************************************\n");
	printf("**               SUSI4.0 demo               **\n");
	printf("**********************************************\n");

	if (iHost >= SUSI_SMBUS_MAX_DEVICE)
	{
		printf("ERROR: The SMbus host is not exist.\n");
		return 1;
	}

	printf("\nSMBus Host: %s\n\n", hostStr[iHost]);

	return 0;
}

static uint8_t select_host(uint8_t *piHost)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("\nSMBus Host:\n");
	for (i = 0; i < SUSI_SMBUS_MAX_DEVICE && host[i] > -1; i++)
	{
		if (host[i] == *piHost)
			printf("%u) [Host %s]\n", i, hostStr[host[i]]);
		else
			printf("%u) Host %s\n", i, hostStr[host[i]]);
	}

	if (i == 1)
	{
		*piHost = host[0];
		printf("Only Host %s is available.\n", hostStr[*piHost]);
		printf("\nPress ENTER to continue. ");
		wait_enter();
		return 0;
	}

	tmp_u32 = 0;
	do {		
		printf("\nEnter your choice (0 to %u): ", i - 1);
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*piHost = host[tmp_u32];

	return 0;
}

static uint8_t probe_address(uint32_t smb_id)
{
	uint32_t status;
	uint8_t addrConv, numItem, i;

	printf("\nProbe:\n");
	printf("Slave address of existed devices:\n");

	numItem = 0;
    for (i = 0; i < 0x80; i++)
    {
		addrConv = (i << 1);
        status = SusiSMBWriteQuick(smb_id, addrConv);
        if (status == SUSI_STATUS_SUCCESS)
		{			
            printf("%2X ", addrConv);
			numItem++;
		}
		else
		{
			if (smb_id == hostExternal)
			{
				if (status != SUSI_STATUS_NOT_FOUND)
					printf("\n%2X SusiSMBWriteQuick() failed. (0x%08X)\n", addrConv, status);
			}
			else
			{
				if (status != SUSI_STATUS_ERROR)
					printf("\n%2X SusiSMBWriteQuick() failed. (0x%08X)\n", addrConv, status);
			}
		}
    }

	if (numItem == 0)
	{
		printf("Fine no device.\n");
		return 1;
	}

	printf("\n");

	return 0;
}

static uint8_t read_data(uint32_t smb_id, SMBParameter smbPara)
{
	uint32_t status, i;
	uint8_t *pdataBuffer;

	pdataBuffer = 0;

	switch (smbPara.protocal)
    {
        case protQuick:
			status = SusiSMBReadQuick(smb_id, smbPara.addr);
            if (status == SUSI_STATUS_SUCCESS)
				printf("Read Quick succeed.\n");
			else
                printf("Read Quick failed. (0x%08X)\n", status);
            break;

        case protByte:
			pdataBuffer = (uint8_t*)malloc(sizeof(uint8_t));

            status = SusiSMBReceiveByte(smb_id, smbPara.addr, pdataBuffer);
            if (status == SUSI_STATUS_SUCCESS)
                printf("Data: %2X\n", *pdataBuffer);
            else
				printf("Receice byte failed. (0x%08X)\n", status);
			free(pdataBuffer);
            break;

        case protByteData:
			pdataBuffer = (uint8_t*)malloc(sizeof(uint8_t));

			status = SusiSMBReadByte(smb_id, smbPara.addr, smbPara.cmd, pdataBuffer);
			if (status == SUSI_STATUS_SUCCESS)
				printf("Data (Hex): %02X\n", *pdataBuffer);
			else
				printf("Read byte data failed. (0x%08X)\n", status);
			free(pdataBuffer);
            break;

        case protWordData:
			pdataBuffer = (uint8_t*)malloc(sizeof(uint16_t));

            status = SusiSMBReadWord(smb_id, smbPara.addr, smbPara.cmd, (uint16_t*)pdataBuffer);
            if (status == SUSI_STATUS_SUCCESS)
                printf("Data (Hex): %04X\n", *((uint16_t*)pdataBuffer));
            else
                printf("Read word data failed. (0x%08X)\n", status);
			free(pdataBuffer);
            break;

        case protBlock:
			pdataBuffer = (uint8_t*)malloc(smbPara.length * sizeof(uint8_t));

            status = SusiSMBReadBlock(smb_id, smbPara.addr, smbPara.cmd, pdataBuffer, &smbPara.length);
			if (status == SUSI_STATUS_MORE_DATA)
			{
				printf("Read block need more length, target size is %u.\n", smbPara.length);
				status = SUSI_STATUS_SUCCESS;
			}

            if (status == SUSI_STATUS_SUCCESS)
            {
				printf("Data (Hex):\n");
				for (i = 0; i < smbPara.length; i++)
					printf("%02X ", pdataBuffer[i]);
				printf("\n");
            }
            else
            {
				printf("Read block data failed. (0x%08X)\n", status);               
            }

			free(pdataBuffer);
            break;

        case protI2CBlock:
			pdataBuffer = (uint8_t*)malloc(smbPara.length * sizeof(uint8_t));

            status = SusiSMBI2CReadBlock(smb_id, smbPara.addr, smbPara.cmd, pdataBuffer, smbPara.length);
            if (status == SUSI_STATUS_SUCCESS)
			{
				printf("Data (Hex):\n");
				for (i = 0; i < smbPara.length; i++)
					printf("%02X ", pdataBuffer[i]);
				printf("\n");
            }                
            else
			{
				printf("Read I2C block data failed. (0x%08X)\n", status);
			}
			free(pdataBuffer);
            break;

        default:
            return 1;
    }

	return 0;
}

static uint8_t write_data(uint32_t smb_id, SMBParameter smbPara)
{
	uint32_t status, i, tmp_u32;
	uint8_t *pdataBuffer;

	pdataBuffer = 0;

	switch (smbPara.protocal)
    {
        case protQuick:
			status = SusiSMBWriteQuick(smb_id, smbPara.addr);
			if (status == SUSI_STATUS_SUCCESS)
				printf("Write Quick succeed.\n");
			else
                printf("Write Quick failed. (0x%08X)\n", status);
            break;

        case protByte:
			do {
				printf("\nInput a BYTE value (Hex): 0x");
			} while (input_uint(&tmp_u32, 16, 0xFF, 0) != 0);

			status = SusiSMBSendByte(smb_id, smbPara.addr, (uint8_t)tmp_u32);
			if (status == SUSI_STATUS_SUCCESS)
				printf("Send byte succeed.\n");
			else
                printf("Send byte failed. (0x%08X)\n", status);
			break;

        case protByteData:
			do {
				printf("\nInput a BYTE value (Hex): 0x");
			} while (input_uint(&tmp_u32, 16, 0xFF, 0) != 0);

			status = SusiSMBWriteByte(smb_id, smbPara.addr, smbPara.cmd, (uint8_t)tmp_u32);
			if (status == SUSI_STATUS_SUCCESS)
				printf("Write byte data succeed.\n");
			else
                printf("Write byte data failed. (0x%08X)\n", status);
            break;

        case protWordData:
			do {
				printf("\nInput a WORD value (Hex): 0x");
			} while (input_uint(&tmp_u32, 16, 0xFFFF, 0) != 0);

			status = SusiSMBWriteWord(smb_id, smbPara.addr, smbPara.cmd, (uint16_t)tmp_u32);
			if (status == SUSI_STATUS_SUCCESS)
				printf("Write word data succeed.\n");
			else
                printf("Write word data failed. (0x%08X)\n", status);
            break;

        case protBlock:
			if (smbPara.length > 0)
			{
				pdataBuffer = (uint8_t*)malloc(smbPara.length * sizeof(uint8_t));
				printf("\nInput %u-byte value (Hex):\n ", smbPara.length);
				if (input_byte_sequence(pdataBuffer, smbPara.length, NULL, 16, 0xFF, 0) != 0)
				{
					if (pdataBuffer > 0)
						free(pdataBuffer);

					printf("Input invalid value.\n");
					return 1;
				}

				printf("\nWrite Data (Hex):\n");
				for (i = 0; i < smbPara.length; i++)
					printf(" %02X", pdataBuffer[i]);
				printf("\n\n");
			}

			status = SusiSMBWriteBlock(smb_id, smbPara.addr, smbPara.cmd, pdataBuffer, smbPara.length);

			if (pdataBuffer > 0)
				free(pdataBuffer);

			if (status == SUSI_STATUS_SUCCESS)
				printf("Write block data succeed.\n");
			else
                printf("Write block data failed. (0x%08X)\n", status);
			break;

        case protI2CBlock:
			if (smbPara.length > 0)
			{
				pdataBuffer = (uint8_t*)malloc(smbPara.length * sizeof(uint8_t));
				printf("\nInput %u-byte value (Hex):\n ", smbPara.length);
				if (input_byte_sequence(pdataBuffer, smbPara.length, NULL, 16, 0xFF, 0) != 0)
				{
					if (pdataBuffer > 0)
						free(pdataBuffer);

					printf("Input invalid value.\n");
					return 1;
				}

				printf("\nWrite Data (Hex):\n");
				for (i = 0; i < smbPara.length; i++)
					printf(" %02X", pdataBuffer[i]);
				printf("\n\n");
			}

			status = SusiSMBI2CWriteBlock(smb_id, smbPara.addr, smbPara.cmd, pdataBuffer, smbPara.length);

			if (pdataBuffer > 0)
				free(pdataBuffer);

			if (status == SUSI_STATUS_SUCCESS)
				printf("Write I2C block data succeed.\n");
			else
                printf("Write I2C block data failed. (0x%08X)\n", status);
            break;

        default:
            return 1;
    }

	return 0;
}

static uint8_t show_menu_write_read(int8_t iFunc, SMBParameter smbPara)
{
	uint8_t i;

	switch (iFunc)
	{
	case funcRead:
		printf("Read Data:\n\n");
		break;
	case funcWrite:
		printf("Write Data:\n\n");
		break;
	default:
		return 1;
	}

	i = 0;

	printf("%u) Protocal: %s\n", i, protocalStr[smbPara.protocal]);
	para[i] = paraProtocal;
	i++;

	printf("%u) Slave Address: 0x%02X\n", i, smbPara.addr);
	para[i] = paraAddr;
	i++;

	if (smbPara.protocal != protQuick && smbPara.protocal != protByte)
	{
		printf("%u) Command: 0x%02X\n", i, smbPara.cmd);
		para[i] = paraCmd;
		i++;
	}

	if (smbPara.protocal == protBlock || smbPara.protocal == protI2CBlock)
	{
		printf("%u) Data Length: %u\n", i, smbPara.length);
		para[i] = paraLen;
		i++;
	}

	printf("%u) Run\n", i);
	para[i] = paraRun;
	i++;

	while (i < SUSIDEMO_SMB_PARAMETER_MAX)
	{
		para[i] = -1;
		i++;
	}

	printf("\nEnter your choice: ");

	return 0;
}

static uint8_t smb_loop_write_read(uint8_t iHost, uint8_t iFunc, PSMBParameter psmbPara)
{
	int32_t op;
	uint32_t tmp_u32;

	psmbPara->addr = 0;
	psmbPara->cmd = 0;
	psmbPara->protocal = protQuick;
	psmbPara->length = 1;

	for (;;)
	{
		clr_screen();
		if (title(iHost) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (show_menu_write_read(iFunc, *psmbPara) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op < 0 || op > SUSIDEMO_SMB_PARAMETER_MAX)
		{
			printf("Unknown choice!\n");
			return 1;
		}

		switch (para[op])
		{
		case paraProtocal:
			printf("Protocal:\n");
			printf("0) Quick\n");
			printf("1) Byte\n");
			printf("2) Byte Data\n");
			printf("3) Word Data\n");
			printf("4) Block\n");
			printf("5) I2C Block\n");

			do {
				printf("\nEnter your choice: ");
			} while (input_uint(&tmp_u32, 10, 5, 0) != 0);

			psmbPara->protocal = (uint8_t)tmp_u32;
			break;

		case paraAddr:
			do {
				printf("Slave Address: 0x");
			} while (input_uint(&tmp_u32, 16, 0xFF, 0) != 0);

			psmbPara->addr = (uint8_t)tmp_u32;
			break;

		case paraCmd:
			do {
				printf("\nCommand: 0x");
			} while (input_uint(&tmp_u32, 16, 0xFF, 0) != 0);			

			psmbPara->cmd = (uint8_t)tmp_u32;
			break;

		case paraLen:
			do {
				printf("\nLength (%u to %u): ", 0x00, 0x20);
			} while (input_uint(&tmp_u32, 10, 0x20, 0) != 0);

			psmbPara->length = (uint8_t)tmp_u32;
			break;

		case paraRun:
			if (psmbPara->protocal == protByteData)
				psmbPara->length = 1;
			else if (psmbPara->protocal == protWordData)
				psmbPara->length = 2;

			return 0;

		default:
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}
	}

	return 1;
}

static uint8_t show_menu(void)
{
	printf("0) Back to Main menu\n");
	printf("1) Select host\n");
	printf("2) Probe\n");
	printf("3) Read\n");
	printf("4) Write\n");	
	printf("\nEnter your choice: ");

	return 0;
}

uint8_t smb_main(void)
{
	int32_t op;
	uint32_t smb_id;
	uint8_t result, iHost;
	SMBParameter smb_para;

	result = 0;

	iHost = host[0];
	smb_id = iHost;

	smb_para.addr = 0;
	smb_para.cmd = 0;
	smb_para.protocal = 0;
	smb_para.length = 0;

	for (;;)
	{
		clr_screen();
		if (title(iHost) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (show_menu() != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op == 0)
		{
			clr_screen();
			break;
		}

		if (op < 1 || op > SUSIDEMO_SMB_FUNCTION_MAX)
		{
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			continue;
		}

		switch (func[op - 1])
		{
		case funcHost:
			result = select_host(&iHost);
			if (result == 0)
				smb_id = iHost;
			break;

		case funcProbe:
			result = probe_address(smb_id);
			break;

		case funcRead:
			if (smb_loop_write_read(iHost, funcRead, &smb_para) == 0)
				result = read_data(smb_id, smb_para);
			break;

		case funcWrite:
			if (smb_loop_write_read(iHost, funcWrite, &smb_para) == 0)
				result = write_data(smb_id, smb_para);
			break;

		default:
			result = 1;
			printf("Unknown choice!\n");
			break;
		}

		if (result != 0 || func[op - 1] != funcHost)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}

	clr_screen();

	return 0;
}