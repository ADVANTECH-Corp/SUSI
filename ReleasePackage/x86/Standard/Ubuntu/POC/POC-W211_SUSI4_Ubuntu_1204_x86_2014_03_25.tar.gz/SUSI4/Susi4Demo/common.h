#ifndef _SUSI_COMMON_H_
#define _SUSI_COMMON_H_

// SUSI include
#include "OsDeclarations.h"
#include "Susi4.h"

// OS
#include "os_windows.h"
#include "os_linux.h"

// Public
#define STRING_MAXIMUM_LENGTH 64
#define NAME_MAXIMUM_LENGTH 32

uint8_t wdog_init(int8_t *pavailable);
uint8_t hwm_init(int8_t *pavailable);
uint8_t smartfan_init(int8_t *pavailable);
uint8_t gpio_init(int8_t *pavailable);
uint8_t vga_init(int8_t *pavailable);
uint8_t smb_init(int8_t *pavailable);
uint8_t iic_init(int8_t *pavailable);
uint8_t storage_init(int8_t *pavailable);
uint8_t thermalprotection_init(int8_t *pavailable);
uint8_t info_init(int8_t *pavailable);

uint8_t wdog_main(void);
uint8_t hwm_main(void);
uint8_t smartfan_main(void);
uint8_t gpio_main(void);
uint8_t vga_main(void);
uint8_t smb_main(void);
uint8_t iic_main(void);
uint8_t storage_main(void);
uint8_t thermalprotection_main(void);
uint8_t info_main(void);

uint8_t input_uint(uint32_t *psetVal, uint8_t base, uint32_t maxVal, uint32_t minVal);
uint8_t input_byte_sequence(uint8_t *pbuffer, uint32_t length, uint32_t *endNumber, uint8_t base, uint8_t maxVal, uint8_t minVal);
void wait_enter(void);
int clr_screen(void);

#endif /*_SUSI_COMMON_H_*/
