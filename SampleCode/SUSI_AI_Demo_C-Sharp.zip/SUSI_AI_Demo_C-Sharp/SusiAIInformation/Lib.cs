﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace Susi4.Plugin
{
    public static class SusiAIInfo
    {
        public const UInt32 SUSI_AI_ID_X86_NV_MAX = 12;
        public const UInt32 SUSI_AI_ID_X86_NV_SN = 0x00026000;
        public const UInt32 SUSI_AI_ID_X86_NV_VOLATILE_UTILITY = SUSI_AI_ID_X86_NV_SN + 1;
        public const UInt32 SUSI_AI_ID_X86_NV_TEMP = SUSI_AI_ID_X86_NV_SN + 2;
        public const UInt32 SUSI_AI_ID_X86_NV_PERF = SUSI_AI_ID_X86_NV_SN + 3;
        public const UInt32 SUSI_AI_ID_X86_NV_POWER_USAGE = SUSI_AI_ID_X86_NV_SN + 4;
        public const UInt32 SUSI_AI_ID_X86_NV_POWER_CAP = SUSI_AI_ID_X86_NV_SN + 5;
        public const UInt32 SUSI_AI_ID_X86_NV_MEM_USAGE = SUSI_AI_ID_X86_NV_SN + 6;
        public const UInt32 SUSI_AI_ID_X86_NV_MEM_TOTAL = SUSI_AI_ID_X86_NV_SN + 7;
        public const UInt32 SUSI_AI_ID_X86_NV_FAN_SPEED = SUSI_AI_ID_X86_NV_SN + 8;
        public const UInt32 SUSI_AI_ID_X86_NV_GET_COUNT = SUSI_AI_ID_X86_NV_SN + 9;
        public const UInt32 SUSI_AI_ID_X86_NV_COMPUTE_MODE = SUSI_AI_ID_X86_NV_SN + 10;
        public const UInt32 SUSI_AI_ID_X86_NV_DISPLAY_ACTIVE = SUSI_AI_ID_X86_NV_SN + 11;

        public const UInt32 SUSI_AI_ID_X86_NV_STR_MAX = 4;
        public const UInt32 SUSI_AI_ID_X86_NV_NAME_STR = SUSI_ID_BASE_GET_NAME_X86_NV_AI;
        public const UInt32 SUSI_AI_ID_X86_NV_DRIVER_VERSION_STR = SUSI_ID_BASE_GET_NAME_X86_NV_AI + 1;
        public const UInt32 SUSI_AI_ID_X86_NV_CUDA_VERSION_STR = SUSI_ID_BASE_GET_NAME_X86_NV_AI + 2;
        public const UInt32 SUSI_AI_ID_X86_NV_CUDNN_VERSION_STR = SUSI_ID_BASE_GET_NAME_X86_NV_AI + 3;

        public const UInt32 USI_AI_ID_DOCKER_COMMON_MAX = 4;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_COUNT = 0x00027000 + 0;
        public const UInt32 SUSI_AI_ID_CONTAINER_COUNT = SUSI_AI_ID_DOCKER_IMG_COUNT + 1;
        public const UInt32 SUSI_AI_ID_CONTAINER_RUN_COUNT = SUSI_AI_ID_DOCKER_IMG_COUNT + 2;
        public const UInt32 SUSI_AI_ID_CONTAINER_PAUSE_COUNT = SUSI_AI_ID_DOCKER_IMG_COUNT + 3;

        public const UInt32 SUSI_AI_ID_DOCKER_IMG_MAX = 1;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_SIZE = 0x00028000;

        public const UInt32 SUSI_AI_ID_DOCKER_IMG_STR_MAX = 6;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_ID_STR = SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_TAG_STR = SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI + 1;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_OS_STR = SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI + 2;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_ARCHITECTURE_STR = SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI + 3;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_BUILD_TIME_STR = SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI + 4;
        public const UInt32 SUSI_AI_ID_DOCKER_IMG_BUILD_VER_STR = SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI + 5;

        //Container
        public const UInt32 SUSI_AI_ID_CONTAINER_MAX = 4;
        public const UInt32 SUSI_AI_ID_CONTAINER_CPU_USAGE = 0x00029000;
        public const UInt32 SUSI_AI_ID_CONTAINER_MEM_USAGE = SUSI_AI_ID_CONTAINER_CPU_USAGE + 1;
        public const UInt32 SUSI_AI_ID_CONTAINER_MEM_USED = SUSI_AI_ID_CONTAINER_CPU_USAGE + 2;
        public const UInt32 SUSI_AI_ID_CONTAINER_MEM_TOTAL = SUSI_AI_ID_CONTAINER_CPU_USAGE + 3;

        public const UInt32 SUSI_AI_ID_CONTAINER_STR_MAX = 8;
        public const UInt32 SUSI_AI_ID_CONTAINER_RUN_ON_IMG_ID_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI;
        public const UInt32 SUSI_AI_ID_CONTAINER_RUN_ON_IMG_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 1;
        public const UInt32 SUSI_AI_ID_CONTAINER_NAME_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 2;
        public const UInt32 SUSI_AI_ID_CONTAINER_ID_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 3;
        public const UInt32 SUSI_AI_ID_CONTAINER_STATUS_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 4;
        public const UInt32 SUSI_AI_ID_CONTAINER_CONN_IP_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 5;
        public const UInt32 SUSI_AI_ID_CONTAINER_CONN_GATEWAY_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 6;
        public const UInt32 SUSI_AI_ID_CONTAINER_CONN_MAC_STR = SUSI_ID_BASE_GET_NAME_CONTAINER_AI + 7;

        public const UInt32 SUSI_ID_BASE_GET_NAME_X86_NV_AI = 0xA0000000;
        public const UInt32 SUSI_ID_BASE_GET_NAME_ARM_NV_AI = 0xB0000000;
        public const UInt32 SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI = 0xC0000000;
        public const UInt32 SUSI_ID_BASE_GET_NAME_CONTAINER_AI = 0xD0000000;
        public const UInt32 SUSI_ID_BASE_GET_NAME_X86_INTEL_AI = 0xE0000000;

        public const UInt32 SUSI_AI_ID_X86_INTEL_MAX = 4;
        public const UInt32 SUSI_AI_ID_X86_INTEL_CPU_USAGE = 0x00030000;
        public const UInt32 SUSI_AI_ID_X86_INTEL_GPU_USAGE = SUSI_AI_ID_X86_INTEL_CPU_USAGE + 1;
        public const UInt32 SUSI_AI_ID_X86_INTEL_CPU_TEMP = SUSI_AI_ID_X86_INTEL_CPU_USAGE + 2;
        public const UInt32 SUSI_AI_ID_X86_INTEL_GPU_TEMP = SUSI_AI_ID_X86_INTEL_CPU_USAGE + 3;

        public const UInt32 SUSI_AI_ID_X86_INTEL_STR_MAX = 2;
        public const UInt32 SUSI_AI_ID_X86_INTEL_CPU_NAME_STR = SUSI_ID_BASE_GET_NAME_X86_INTEL_AI;
        public const UInt32 SUSI_AI_ID_X86_INTEL_GPU_NAME_STR = SUSI_ID_BASE_GET_NAME_X86_INTEL_AI + 1;
        public static UInt32 SUSI_ID_MAPPING_GET_NAME_X86_NV_AI(UInt32 Id)
        {
            return (Id | SUSI_ID_BASE_GET_NAME_X86_NV_AI);
        }
        public static UInt32 SUSI_ID_MAPPING_GET_NAME_X86_INTEL_AI(UInt32 Id)
        {
            return (Id | SUSI_ID_BASE_GET_NAME_X86_INTEL_AI);
        }
        public static UInt32 SUSI_ID_MAPPING_GET_NAME_ARM_NV_AI(UInt32 Id)
        {
            return (Id | SUSI_ID_BASE_GET_NAME_ARM_NV_AI);
        }
        public static UInt32 SUSI_ID_MAPPING_GET_NAME_DOCKER_IMG_AI(UInt32 Id)
        {
            return (Id | SUSI_ID_BASE_GET_NAME_DOCKER_IMG_AI);
        }
        public static UInt32 SUSI_ID_MAPPING_GET_NAME_CONTAINER_AI(UInt32 Id)
        {
            return (Id | SUSI_ID_BASE_GET_NAME_CONTAINER_AI);
        }
        public static UInt32 SUSI_ID_MAPPING_GET_VALUE(UInt32 Id, UInt32 index)
        {
            return (Id | (index << 20));
        }
        public static UInt32 SUSI_ID_MAPPING_GET_ITEM(UInt32 Id)
        {
            return (Id & 0xF00FFFFF);
        }

        public const UInt32 SUSI_ID_AI_SUPPORT_FLAGS = 0x00000000;

        // Support Flags
        public const UInt32 SUSI_AI_FLAG_SUPPORT_X86_NV = 0x00000002;
        public const UInt32 SUSI_AI_FLAG_SUPPORT_ARM_NV = 0x00000004;
        public const UInt32 SUSI_AI_FLAG_SUPPORT_DOCKER_IMG = 0x00000008;
        public const UInt32 SUSI_AI_FLAG_SUPPORT_CONTAINER = 0x00000010;
        public const UInt32 SUSI_AI_FLAG_SUPPORT_X86_INTEL = 0x00000020;

        [DllImport("SUSIAI")]
        public static extern UInt32 SusiAIInitialize();

        [DllImport("SUSIAI")]
        public static extern UInt32 SusiAIGetCaps(UInt32 Id, ref UInt32 pValue);

        [DllImport("SUSIAI")]
        public static extern UInt32 SusiAIGetValue(UInt32 Id, ref UInt32 pValue);

        [DllImport("SUSIAI")]
        public static extern UInt32 SusiAIGetStringA(UInt32 Id, StringBuilder pBuffer, ref UInt32 pBufLen);
    }
}