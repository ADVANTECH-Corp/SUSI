﻿namespace Susi4.Plugin
{
    partial class ctlMain
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listView_AiInfo = new System.Windows.Forms.ListView();
            this.columnHeader_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_Content = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_Unit = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox_AiInfoList = new System.Windows.Forms.GroupBox();
            this.timer_monitorAi = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // listView_AiInfo
            // 
            this.listView_AiInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView_AiInfo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_Name,
            this.columnHeader_Content,
            this.columnHeader_Unit});
            this.listView_AiInfo.Location = new System.Drawing.Point(6, 56);
            this.listView_AiInfo.Name = "listView_AiInfo";
            this.listView_AiInfo.Size = new System.Drawing.Size(624, 344);
            this.listView_AiInfo.TabIndex = 0;
            this.listView_AiInfo.UseCompatibleStateImageBehavior = false;
            this.listView_AiInfo.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader_Name
            // 
            this.columnHeader_Name.Text = "Item Name";
            this.columnHeader_Name.Width = 192;
            // 
            // columnHeader_Content
            // 
            this.columnHeader_Content.Text = "Content";
            this.columnHeader_Content.Width = 324;
            // 
            // columnHeader_Unit
            // 
            this.columnHeader_Unit.Text = "Unit";
            // 
            // groupBox_AiInfoList
            // 
            this.groupBox_AiInfoList.Location = new System.Drawing.Point(6, 0);
            this.groupBox_AiInfoList.Name = "groupBox_AiInfoList";
            this.groupBox_AiInfoList.Size = new System.Drawing.Size(621, 50);
            this.groupBox_AiInfoList.TabIndex = 64;
            this.groupBox_AiInfoList.TabStop = false;
            this.groupBox_AiInfoList.Text = "AI List";
            // 
            // timer_monitorAi
            // 
            this.timer_monitorAi.Interval = 2000;
            this.timer_monitorAi.Tick += new System.EventHandler(this.timer_monitorAi_Tick);
            // 
            // ctlMain
            // 
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.groupBox_AiInfoList);
            this.Controls.Add(this.listView_AiInfo);
            this.MinimumSize = new System.Drawing.Size(630, 400);
            this.Name = "ctlMain";
            this.Size = new System.Drawing.Size(630, 400);
            this.Load += new System.EventHandler(this.PageInfo_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView_AiInfo;
        private System.Windows.Forms.ColumnHeader columnHeader_Name;
        private System.Windows.Forms.ColumnHeader columnHeader_Content;
        private System.Windows.Forms.GroupBox groupBox_AiInfoList;
        private System.Windows.Forms.ColumnHeader columnHeader_Unit;
        private System.Windows.Forms.Timer timer_monitorAi;
    }
}
