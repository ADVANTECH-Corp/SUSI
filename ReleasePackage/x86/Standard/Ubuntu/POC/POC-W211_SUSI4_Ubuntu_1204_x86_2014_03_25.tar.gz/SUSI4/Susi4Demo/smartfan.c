#include "common.h"

static const char *fanStr[] = {
    "CPU",
    "System",
    "CPU 2",
    "OEM0",
    "OEM1",
    "OEM2",
    "OEM3",
    "OEM4",
    "OEM5",
    "OEM6"
};

static const char *tempStr[] = {
    "CPU",
    "CHIPSET",
    "SYSTEM",
    "CPU2",
    "OEM0",
    "OEM1",
    "OEM2",
    "OEM3",
    "OEM4",
    "OEM5"
};

typedef struct
{
	uint32_t ctrlFlag;
	uint32_t autoFlag;
	int32_t temp[SUSI_ID_HWM_TEMP_MAX];
} FanInfo, *PFanInfo;

static FanInfo info[SUSI_ID_HWM_FAN_MAX];
static int8_t fan[SUSI_ID_HWM_FAN_MAX];

#define SUSIDEMO_FANCONTROL_MODE_MAX 4
static int8_t mode[SUSIDEMO_FANCONTROL_MODE_MAX];
static const char *modeStr[] = {
    "Off",
	"Full",
    "Manual",
    "Auto"
};
/*enum modeRank{
	modeOff,
	modeFull,
	modeManual,
	modeAuto      
};*/

#define SUSIDEMO_FANCONTROL_AUTO_OPMODE_MAX 2
static int8_t opmode[SUSIDEMO_FANCONTROL_AUTO_OPMODE_MAX];
static const char *opmodeStr[] = {
    "PWM",
	"RPM"
};
/*enum opmodeRank{
	opmodePWM,
	opmodeRPM   
};*/

#define SUSIDEMO_FANCONTROL_FUNCTION_MAX 14
static int8_t func[SUSIDEMO_FANCONTROL_FUNCTION_MAX];
enum funcRank{
	funcFan,
	funcMode,
	funcPWM,
	funcTmlSource,
	funcLowStopLimit,
	funcLowLimit,
	funcHighLimit,
	funcOpMode,
	funcMaxPWM,
	funcMinPWM,
	funcMaxRPM,
	funcMinRPM,
	funcGet,
	funcSet
};

uint8_t smartfan_init(int8_t *pavailable)
{
	uint32_t status, fan_id, temp_id, temp_type;
	uint8_t fan_index, temp_index, i, j;
	SusiFanControl config;

	*pavailable = 0;

	fan_index = 0;
    for (i = 0; i < SUSI_ID_HWM_FAN_MAX; i++)
    {
		fan_id = SUSI_ID_HWM_FAN_BASE + i;

		/* Get configuration */
        status = SusiFanControlGetConfig(fan_id, &config);
        if (status != SUSI_STATUS_SUCCESS)
            continue;

        /* Get supported item */
		SusiFanControlGetCaps(fan_id, SUSI_ID_FC_CONTROL_SUPPORT_FLAGS, &info[fan_index].ctrlFlag);
		SusiFanControlGetCaps(fan_id, SUSI_ID_FC_AUTO_SUPPORT_FLAGS, &info[fan_index].autoFlag);

        /* Get supported temperature */
		temp_index = 0;
        for (j = 0; j < SUSI_ID_HWM_TEMP_MAX; j++)
        {
			temp_id = SUSI_ID_HWM_TEMP_BASE + j;
            status = SusiFanControlGetCaps(fan_id, temp_id, &temp_type);
            if (status == SUSI_STATUS_SUCCESS)
            {
				info[fan_index].temp[temp_index] = j;
				temp_index++;
            }
        }

		for (j = temp_index; j < SUSI_ID_HWM_TEMP_MAX; j++)
			info[fan_index].temp[j] = -1;

		fan[fan_index] = i;
		fan_index++;
    }

	if (fan_index == 0)
		return 0;

	for (i = fan_index; i < SUSI_ID_HWM_FAN_MAX; i++)
		fan[i] = -1;

	*pavailable = 1;

	return 0;
}

static uint8_t title(uint8_t iFan)
{
	printf("**********************************************\n");
	printf("**               SUSI4.0 demo               **\n");
	printf("**********************************************\n");

	if (iFan >= SUSI_ID_HWM_FAN_MAX)
	{
		printf("ERROR: The fan is not exist.\n");
		return 1;
	}

	printf("\nSmart Fan: Fan %s\n\n", fanStr[iFan]);

	return 0;
}

static uint8_t support_mode_init(uint8_t iFan)
{
	uint8_t index, i;

	index = 0;
	for (i = 0; i < SUSIDEMO_FANCONTROL_MODE_MAX; i++)
	{
		if ((info[iFan].ctrlFlag & (1 << i)) != 0)
		{
			mode[index] = i;
			index++;
		}
	}

	if (index == 0)
	{
		printf("ERROR: Fan %s has no mode supported.\n", fanStr[fan[iFan]]);
		return 1;
	}

	for (i = index; i < SUSIDEMO_FANCONTROL_MODE_MAX; i++)
		mode[i] = -1;

	return 0;
}

static uint8_t support_opmode_init(uint8_t iFan)
{
	uint8_t index, i;

	if ((info[iFan].ctrlFlag & SUSI_FC_FLAG_SUPPORT_AUTO_MODE) == 0)
	{
		for (i = 0; i < SUSIDEMO_FANCONTROL_AUTO_OPMODE_MAX; i++)
			opmode[i] = -1;

		return 0;
	}

	index = 0;

	if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_PWM) != 0)
	{			
		opmode[index] = SUSI_FAN_AUTO_CTRL_OPMODE_PWM;
		index++;
	}

	if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_RPM) != 0)
	{
		opmode[index] = SUSI_FAN_AUTO_CTRL_OPMODE_RPM;
		index++;
	}

	for (i = index; i < SUSIDEMO_FANCONTROL_AUTO_OPMODE_MAX; i++)
		opmode[i] = -1;

	return 0;
}

static uint8_t fan_control_init(uint8_t iFan)
{
	uint8_t result;

	result = support_mode_init(iFan);
	if (result != 0)
	{
		printf("ERROR: Fan %s has no mode supported.\n", fanStr[iFan]);
		return 1;
	}

	result = support_opmode_init(iFan);
	if (result != 0)
	{
		printf("ERROR: Fan %s support_opmode_init failed.\n", fanStr[iFan]);
		return 1;
	}

	return 0;
}

static uint8_t select_fan(uint8_t *piFan)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("\nFan Controller:\n");
	for (i = 0; i < SUSI_ID_HWM_FAN_MAX && fan[i] > -1; i++)
	{
		if (fan[i] == *piFan)
			printf("%u) [Channel - %s]\n", i, fanStr[fan[i]]);
		else
			printf("%u) Channel - %s\n", i, fanStr[fan[i]]);
	}

	if (i == 1)
	{
		*piFan = fan[0];
		printf("Only Channel - %s is available.\n", fanStr[*piFan]);
		printf("\nPress ENTER to continue. ");
		wait_enter();
		return 0;
	}

	tmp_u32 = 0;
	do {
		printf("\nEnter your choice (0 to %u): ", i - 1);
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*piFan = fan[tmp_u32];

	return 0;
}

static uint8_t select_mode(uint8_t iFan, uint32_t *pmode)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("Mode:\n");
	for (i = 0; i < SUSIDEMO_FANCONTROL_MODE_MAX && mode[i] > -1; i++)
	{
		if (i == *pmode)
			printf("%u) [%s]\n", i, modeStr[mode[i]]);
		else
			printf("%u) %s\n", i, modeStr[mode[i]]);
	}

	tmp_u32 = 0;
	do {
		printf("\nEnter your choice: ");
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*pmode = mode[tmp_u32];

	return 0;
}

static uint8_t select_thermal_source(uint8_t iFan, uint32_t *ptmlSource)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("Thermal Source:\n");
	for (i = 0; i < SUSI_ID_HWM_TEMP_MAX && info[iFan].temp[i] > -1; i++)
	{
		if (info[iFan].temp[i] == *ptmlSource)
			printf("%u) [Temp %s]\n", i, tempStr[info[iFan].temp[i]]);
		else
			printf("%u) Temp %s\n", i, tempStr[info[iFan].temp[i]]);
	}

	tmp_u32 = 0;
	do {
		printf("\nEnter your choice: ");
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*ptmlSource = (info[iFan].temp[tmp_u32] & 0x00000FFF) | SUSI_ID_HWM_TEMP_BASE;

	return 0;
}

static uint8_t change_opmode(uint8_t iFan, uint32_t *popMode)
{
	if (*popMode == SUSI_FAN_AUTO_CTRL_OPMODE_PWM)
	{
		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_RPM) != 0)
			*popMode = SUSI_FAN_AUTO_CTRL_OPMODE_RPM;
	}
	else if (*popMode == SUSI_FAN_AUTO_CTRL_OPMODE_RPM)
	{
		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_PWM) != 0)
			*popMode = SUSI_FAN_AUTO_CTRL_OPMODE_PWM;
	}
	else
	{
		if (opmode[0] < 0)
		{
			printf("No Op Mode is supported.\n");
			return 1;
		}

		*popMode = opmode[0];
	}

	return 0;
}

static uint8_t get_config(uint32_t fan_id, PSusiFanControl pconfig)
{
    uint32_t status;

    status = SusiFanControlGetConfig(fan_id, pconfig);
    if (status != SUSI_STATUS_SUCCESS)
    {
        printf("SusiFanControlGetConfig() failed. (0x%08X)\n", status);
        return 1;
    }

	return 0;
}

static uint8_t set_config(uint32_t fan_id, PSusiFanControl pconfig)
{
	uint32_t status;

    status = SusiFanControlSetConfig(fan_id, pconfig);
    if (status != SUSI_STATUS_SUCCESS)
    {
        printf("SusiFanControlSetConfig() failed. (0x%08X)\n", status);
        return 1;
    }

	printf("SusiFanControlSetConfig() succeed.\n");
	return 0;
}

static uint8_t show_menu(uint8_t iFan, SusiFanControl getConf, SusiFanControl setConf)
{
	uint8_t mode_index, opmode_index, i;

	printf("0) Back to Main menu\n");

	i = 0;

	printf("%u) Select fan controller\n", i + 1);
	func[i] = funcFan;
	i++;

	printf("%u) Mode: ", i + 1);
	for (mode_index = 0; mode_index < SUSIDEMO_FANCONTROL_MODE_MAX && mode[mode_index] > -1; mode_index++)
	{
		if (mode_index > 0)
			printf("/");

		if (mode_index == getConf.Mode)
			printf("[%s]", modeStr[mode[mode_index]]);
		else
			printf(" %s ", modeStr[mode[mode_index]]);
	}
	setConf.Mode != getConf.Mode ? printf(" -> %s\n", modeStr[setConf.Mode]) : printf("\n");
	func[i] = funcMode;
	i++;
	
	switch(setConf.Mode)
	{
	case SUSI_FAN_CTRL_MODE_OFF:
	case SUSI_FAN_CTRL_MODE_FULL:
		break;

	case SUSI_FAN_CTRL_MODE_MANUAL:
		printf("%u) PWM: %u%%", i + 1, getConf.PWM);
		setConf.PWM != getConf.PWM ? printf(" -> %u%%\n", setConf.PWM) : printf("\n");
		func[i] = funcPWM;
		i++;
		break;

	case SUSI_FAN_CTRL_MODE_AUTO:
		if (info[iFan].temp[0] > -1)
		{
			if ((getConf.AutoControl.TmlSource & 0x000FF000) == SUSI_ID_HWM_TEMP_BASE)
				printf("%u) Thermal Source: Temperature %s", i + 1, tempStr[getConf.AutoControl.TmlSource - SUSI_ID_HWM_TEMP_BASE]);
			else
				printf("%u) Thermal Source: N/A", i + 1);

			if ((setConf.AutoControl.TmlSource & 0x000FF000) == SUSI_ID_HWM_TEMP_BASE)
			{
				setConf.AutoControl.TmlSource != getConf.AutoControl.TmlSource ? printf(" -> %s\n", tempStr[setConf.AutoControl.TmlSource - SUSI_ID_HWM_TEMP_BASE]) : printf("\n");
			}
			else
			{
				setConf.AutoControl.TmlSource = getConf.AutoControl.TmlSource;
				printf("\n");
			}

			func[i] = funcTmlSource;
			i++;
		}

		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_LOW_STOP) != 0)
		{
			printf("%u) Low Stop Limit: %.1f", i + 1, SUSI_DECODE_CELCIUS((float)getConf.AutoControl.LowStopLimit));
			setConf.AutoControl.LowStopLimit != getConf.AutoControl.LowStopLimit ? printf(" -> %.1f Celsius\n", SUSI_DECODE_CELCIUS((float)setConf.AutoControl.LowStopLimit)) : printf(" Celsius\n");
			func[i] = funcLowStopLimit;
			i++;
		}

		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_LOW_LIMIT) != 0)
		{
			printf("%u) Low Limit: %.1f", i + 1, SUSI_DECODE_CELCIUS((float)getConf.AutoControl.LowLimit));
			setConf.AutoControl.LowLimit != getConf.AutoControl.LowLimit ? printf(" -> %.1f Celsius\n", SUSI_DECODE_CELCIUS((float)setConf.AutoControl.LowLimit)) : printf(" Celsius\n");
			func[i] = funcLowLimit;
			i++;
		}

		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_HIGH_LIMIT) != 0)
		{
			printf("%u) High Limit: %.1f", i + 1, SUSI_DECODE_CELCIUS((float)getConf.AutoControl.HighLimit));
			setConf.AutoControl.HighLimit != getConf.AutoControl.HighLimit ? printf(" -> %.1f Celsius\n", SUSI_DECODE_CELCIUS((float)setConf.AutoControl.HighLimit)) : printf(" Celsius\n");
			func[i] = funcHighLimit;
			i++;
		}

		for (opmode_index = 0; opmode_index < SUSIDEMO_FANCONTROL_AUTO_OPMODE_MAX && opmode[opmode_index] > -1; opmode_index++)
		{
			if (opmode_index == 0)
				printf("%u) Op Mode: ", i + 1);
			else
				printf("/");

			if (getConf.AutoControl.OpMode == opmode[opmode_index])
				printf("[%s]", opmodeStr[opmode[opmode_index]]);
			else
				printf("%s", opmodeStr[opmode[opmode_index]]);
		}
		if (opmode_index > 0)
		{
			setConf.AutoControl.OpMode != getConf.AutoControl.OpMode ? printf(" -> [%s]\n", opmodeStr[setConf.AutoControl.OpMode]) : printf("\n");
			func[i] = funcOpMode;
			i++;
		}

		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_PWM) != 0 && setConf.AutoControl.OpMode == SUSI_FAN_AUTO_CTRL_OPMODE_PWM)
		{
			printf("%u) Max PWM: %u%%", i + 1, getConf.AutoControl.MaxPWM);
			setConf.AutoControl.MaxPWM != getConf.AutoControl.MaxPWM ? printf(" -> %u%%\n", setConf.AutoControl.MaxPWM) : printf("\n");
			
			printf("%u) Min PWM: %u%%", i + 2, getConf.AutoControl.MinPWM);
			setConf.AutoControl.MinPWM != getConf.AutoControl.MinPWM ? printf(" -> %u%%\n", setConf.AutoControl.MinPWM) : printf("\n");

			func[i] = funcMaxPWM;
			func[i + 1] = funcMinPWM;
			i += 2;
		}

		if ((info[iFan].autoFlag & SUSI_FC_FLAG_SUPPORT_AUTO_RPM) != 0 && setConf.AutoControl.OpMode == SUSI_FAN_AUTO_CTRL_OPMODE_RPM)
		{
			printf("%u) Max RPM: %u", i + 1, getConf.AutoControl.MaxRPM);
			setConf.AutoControl.MaxRPM != getConf.AutoControl.MaxRPM ? printf(" -> %u RPM\n", setConf.AutoControl.MaxRPM) : printf(" RPM\n");

			printf("%u) Min RPM: %u", i + 2, getConf.AutoControl.MinRPM);
			setConf.AutoControl.MinRPM != getConf.AutoControl.MinRPM ? printf(" -> %u RPM\n", setConf.AutoControl.MinRPM) : printf(" RPM\n");

			func[i] = funcMaxRPM;
			func[i + 1] = funcMinRPM;
			i += 2;
		}
		break;
	}	

	printf("%u) Get/Refresh all values\n", i + 1);
	printf("%u) Save and apply setting\n", i + 2);
	func[i] = funcGet;
	func[i + 1] = funcSet;
	i += 2;

	while (i < SUSIDEMO_FANCONTROL_FUNCTION_MAX)
	{
		func[i] = -1;
		i++;
	}

	printf("\nEnter your choice: ");

	return 0;
}

uint8_t smartfan_main(void)
{
	int32_t op;
	uint32_t fan_id, tmp_u32;
	uint8_t iFan, result;
	SusiFanControl getConf, setConf;
	
	clr_screen();

	iFan = fan[0];
	fan_id = SUSI_ID_HWM_FAN_BASE + iFan;

	if (get_config(fan_id, &getConf) != 0)
	{
		printf("\nPress ENTER to continue. ");
		wait_enter();			
		return 1;
	}	

	fan_control_init(iFan);	
	setConf = getConf;
	
	for (;;)
	{
		clr_screen();
		if (title(iFan) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();			
			break;
		}		

		if (get_config(iFan, &getConf) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();			
			break;
		}

		show_menu(iFan, getConf, setConf);

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op == 0)
		{
			clr_screen();
			break;
		}

		if (op < 1 || op > SUSIDEMO_FANCONTROL_FUNCTION_MAX)
		{
			printf("\nUnknown choice!\n\n");
			continue;
		}

		result = 0;
		switch (func[op - 1])
		{
		case funcFan:
			result = select_fan(&iFan);
			if (result == 0)
			{
				fan_id = SUSI_ID_HWM_FAN_BASE + iFan;
				fan_control_init(iFan);

				if (get_config(iFan, &getConf) != 0)
				{
					printf("\nPress ENTER to continue. ");
					wait_enter();
					break;
				}

				setConf = getConf;
			}
			break;

		case funcMode:
			setConf.Mode = getConf.Mode;
			result = select_mode(iFan, &setConf.Mode);
			break;

		case funcPWM:
			do {
				printf("\nPWM (0 ~ 100 percentage): ");
			} while (input_uint(&setConf.PWM, 10, 100, 0) != 0);
			break;

		case funcTmlSource:
			setConf.AutoControl.TmlSource = getConf.AutoControl.TmlSource;
			result = select_thermal_source(iFan, &setConf.AutoControl.TmlSource);
			break;

		case funcLowStopLimit:
			do {
				printf("\nLow Stop Limit (0 ~ 255 Celsius): ");
			} while (input_uint(&tmp_u32, 10, 0xFF, 0) != 0);
			setConf.AutoControl.LowStopLimit = SUSI_ENCODE_CELCIUS(tmp_u32);
			break;

		case funcLowLimit:
			do {
				printf("\nLow Limit (0 ~ 255 Celsius): ");
			} while (input_uint(&tmp_u32, 10, 0xFF, 0) != 0);
			setConf.AutoControl.LowLimit = SUSI_ENCODE_CELCIUS(tmp_u32);
			break;

		case funcHighLimit:
			do {
				printf("\nHigh Limit (0 ~ 255 Celsius): ");
			} while (input_uint(&tmp_u32, 10, 0xFF, 0) != 0);
			setConf.AutoControl.HighLimit = SUSI_ENCODE_CELCIUS(tmp_u32);
			break;

		case funcOpMode:
			result = change_opmode(iFan, &setConf.AutoControl.OpMode);			
			break;

		case funcMaxPWM:
			do {
				printf("\nMax PWM (0 ~ 100): ");
			} while (input_uint(&setConf.AutoControl.MaxPWM, 10, 100, 0) != 0);
			break;

		case funcMinPWM:
			do {
				printf("\nMin PWM (0 ~ 100): ");
			} while (input_uint(&setConf.AutoControl.MinPWM, 10, 100, 0) != 0);
			break;

		case funcMaxRPM:
			do {
				printf("\nMax RPM (0 ~ 65535): ");
			} while (input_uint(&setConf.AutoControl.MaxRPM, 10, 0xFFFF, 0) != 0);
			break;

		case funcMinRPM:
			do {
				printf("\nMin RPM (0 ~ 65535): ");
			} while (input_uint(&setConf.AutoControl.MinRPM, 10, 0xFFFF, 0) != 0);
			break;

		case funcGet:
			continue;

		case funcSet:
			result = set_config(fan_id, &setConf);
			break;

		default:
			result = 1;
			printf("\nUnknown choice!\n\n");
			break;
		}

		if (result != 0 || func[op - 1] == funcSet)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}

	clr_screen();
	return 0;
}
