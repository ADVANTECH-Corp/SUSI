﻿namespace Susi4.Plugin
{
    partial class PageRealTimeStatus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_Current_hard_off_timer = new System.Windows.Forms.Label();
            this.label_Current_timer_press_power_button_for_power_off = new System.Windows.Forms.Label();
            this.label_Current_retry_times_Press_power_button_for_power_off = new System.Windows.Forms.Label();
            this.label_48V_output = new System.Windows.Forms.Label();
            this.label_Current_low_battery_detection_timer = new System.Windows.Forms.Label();
            this.label_Current_power_input = new System.Windows.Forms.Label();
            this.label_Current_Ignition_off_timer = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label_Current_IGN_status = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // label_Current_hard_off_timer
            // 
            this.label_Current_hard_off_timer.AutoSize = true;
            this.label_Current_hard_off_timer.Location = new System.Drawing.Point(152, 186);
            this.label_Current_hard_off_timer.Name = "label_Current_hard_off_timer";
            this.label_Current_hard_off_timer.Size = new System.Drawing.Size(15, 15);
            this.label_Current_hard_off_timer.TabIndex = 65;
            this.label_Current_hard_off_timer.Text = "--";
            // 
            // label_Current_timer_press_power_button_for_power_off
            // 
            this.label_Current_timer_press_power_button_for_power_off.AutoSize = true;
            this.label_Current_timer_press_power_button_for_power_off.Location = new System.Drawing.Point(317, 160);
            this.label_Current_timer_press_power_button_for_power_off.Name = "label_Current_timer_press_power_button_for_power_off";
            this.label_Current_timer_press_power_button_for_power_off.Size = new System.Drawing.Size(15, 15);
            this.label_Current_timer_press_power_button_for_power_off.TabIndex = 64;
            this.label_Current_timer_press_power_button_for_power_off.Text = "--";
            // 
            // label_Current_retry_times_Press_power_button_for_power_off
            // 
            this.label_Current_retry_times_Press_power_button_for_power_off.AutoSize = true;
            this.label_Current_retry_times_Press_power_button_for_power_off.Location = new System.Drawing.Point(317, 136);
            this.label_Current_retry_times_Press_power_button_for_power_off.Name = "label_Current_retry_times_Press_power_button_for_power_off";
            this.label_Current_retry_times_Press_power_button_for_power_off.Size = new System.Drawing.Size(15, 15);
            this.label_Current_retry_times_Press_power_button_for_power_off.TabIndex = 63;
            this.label_Current_retry_times_Press_power_button_for_power_off.Text = "--";
            // 
            // label_48V_output
            // 
            this.label_48V_output.AutoSize = true;
            this.label_48V_output.Location = new System.Drawing.Point(93, 110);
            this.label_48V_output.Name = "label_48V_output";
            this.label_48V_output.Size = new System.Drawing.Size(15, 15);
            this.label_48V_output.TabIndex = 62;
            this.label_48V_output.Text = "--";
            // 
            // label_Current_low_battery_detection_timer
            // 
            this.label_Current_low_battery_detection_timer.AutoSize = true;
            this.label_Current_low_battery_detection_timer.Location = new System.Drawing.Point(221, 85);
            this.label_Current_low_battery_detection_timer.Name = "label_Current_low_battery_detection_timer";
            this.label_Current_low_battery_detection_timer.Size = new System.Drawing.Size(15, 15);
            this.label_Current_low_battery_detection_timer.TabIndex = 60;
            this.label_Current_low_battery_detection_timer.Text = "--";
            // 
            // label_Current_power_input
            // 
            this.label_Current_power_input.AutoSize = true;
            this.label_Current_power_input.Location = new System.Drawing.Point(142, 61);
            this.label_Current_power_input.Name = "label_Current_power_input";
            this.label_Current_power_input.Size = new System.Drawing.Size(15, 15);
            this.label_Current_power_input.TabIndex = 59;
            this.label_Current_power_input.Text = "--";
            // 
            // label_Current_Ignition_off_timer
            // 
            this.label_Current_Ignition_off_timer.AutoSize = true;
            this.label_Current_Ignition_off_timer.Location = new System.Drawing.Point(167, 35);
            this.label_Current_Ignition_off_timer.Name = "label_Current_Ignition_off_timer";
            this.label_Current_Ignition_off_timer.Size = new System.Drawing.Size(15, 15);
            this.label_Current_Ignition_off_timer.TabIndex = 58;
            this.label_Current_Ignition_off_timer.Text = "--";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(20, 186);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(129, 15);
            this.label26.TabIndex = 56;
            this.label26.Text = "Current hard off timer: ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(20, 160);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(291, 15);
            this.label27.TabIndex = 55;
            this.label27.Text = "Current retry timer Press power button for power off: ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(20, 136);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(294, 15);
            this.label28.TabIndex = 54;
            this.label28.Text = "Current retry times Press power button for power off: ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(20, 110);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(71, 15);
            this.label29.TabIndex = 53;
            this.label29.Text = "48V output: ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(20, 85);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(199, 15);
            this.label31.TabIndex = 51;
            this.label31.Text = "Current low battery detection timer: ";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(20, 60);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(121, 15);
            this.label32.TabIndex = 50;
            this.label32.Text = "Current power input: ";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(20, 35);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(141, 15);
            this.label33.TabIndex = 49;
            this.label33.Text = "Current Ignition off timer:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(20, 10);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(115, 15);
            this.label35.TabIndex = 46;
            this.label35.Text = "Current IGN status: ";
            // 
            // label_Current_IGN_status
            // 
            this.label_Current_IGN_status.AutoSize = true;
            this.label_Current_IGN_status.Location = new System.Drawing.Point(132, 10);
            this.label_Current_IGN_status.Name = "label_Current_IGN_status";
            this.label_Current_IGN_status.Size = new System.Drawing.Size(15, 15);
            this.label_Current_IGN_status.TabIndex = 47;
            this.label_Current_IGN_status.Text = "--";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // PageRealTimeStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label_Current_hard_off_timer);
            this.Controls.Add(this.label_Current_timer_press_power_button_for_power_off);
            this.Controls.Add(this.label_Current_retry_times_Press_power_button_for_power_off);
            this.Controls.Add(this.label_48V_output);
            this.Controls.Add(this.label_Current_low_battery_detection_timer);
            this.Controls.Add(this.label_Current_power_input);
            this.Controls.Add(this.label_Current_Ignition_off_timer);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label_Current_IGN_status);
            this.Font = new System.Drawing.Font("Arial", 9F);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PageRealTimeStatus";
            this.Size = new System.Drawing.Size(630, 429);
            this.Load += new System.EventHandler(this.PageRealTimeStatus_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Current_hard_off_timer;
        private System.Windows.Forms.Label label_Current_timer_press_power_button_for_power_off;
        private System.Windows.Forms.Label label_Current_retry_times_Press_power_button_for_power_off;
        private System.Windows.Forms.Label label_48V_output;
        private System.Windows.Forms.Label label_Current_low_battery_detection_timer;
        private System.Windows.Forms.Label label_Current_power_input;
        private System.Windows.Forms.Label label_Current_Ignition_off_timer;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label_Current_IGN_status;
        private System.Windows.Forms.Timer timer1;
    }
}
