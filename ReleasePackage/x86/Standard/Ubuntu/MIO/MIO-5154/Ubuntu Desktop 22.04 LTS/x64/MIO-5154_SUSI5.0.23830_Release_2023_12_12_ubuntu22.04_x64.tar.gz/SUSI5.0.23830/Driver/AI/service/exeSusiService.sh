#!/usr/bin/env bash 
 
 clear
 
   sudo ./Susi_X86_64_Service 
 
 
