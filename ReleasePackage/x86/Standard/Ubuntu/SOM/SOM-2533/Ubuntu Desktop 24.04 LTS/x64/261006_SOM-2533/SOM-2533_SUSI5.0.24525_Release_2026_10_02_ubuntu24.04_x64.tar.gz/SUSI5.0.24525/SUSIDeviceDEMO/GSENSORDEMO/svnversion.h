#ifndef __SVN_REVISION_H__
#define __SVN_REVISION_H__
#define SVN_REVISION 24525
#endif /* __SVN_REVISION_H__ */
