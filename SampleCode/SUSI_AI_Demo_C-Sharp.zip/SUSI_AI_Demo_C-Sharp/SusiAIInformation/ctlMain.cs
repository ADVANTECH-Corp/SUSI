﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Susi4.APIs;

namespace Susi4.Plugin
{
    public partial class ctlMain : UserControl
    {
        string[,] infoX86Val = new string[,] {
            {"GPU Current ID",  ""},
            {"GPU Usage",       "%"},
            {"GPU Temp.",       "Celsius"},
            {"GPU Perf.",       ""},
            {"Power Usage",     "W"},
            {"Power Cap.",      "W"},
            {"Memory Inuse",    "MiB"},
            {"Memory Total",    "MiB"},
            {"Fan Speed",       "%" },
            {"Numbers of GPU",  ""},
            {"Compute Mode",    "" },
            {"Display Active",  "" }
        };
        string[] ComputeMode = new string[] {
            "Default",
            "Exclusive_Thread",
            "Prohibited",
            "Exclusive_process",
            "Others"
        };
        string[] DisplayActive = new string[] {
            "OFF",
            "ON"
        };
        string[] infoX86Str = new string[] {
            "GPU Name",
            "Driver Version",
            "CUDA Version",
            "CUDNN Version"
        };
        string[,] infoDockerImgVal = new string[,] {
            {"Image Size", "KB"}
        };

        string[] infoDockerImgStr = new string[] {
            "Image ID",
            "Image Tag",
            "Image base",
            "Architecture",
            "Build Time",
            "Build On Docker"
        };
        string[,] infoContainerVal = new string[,] {
            {"CPU Usage",       "%"},
            {"Memory Usage",    "%"},
            {"Memory Inuse",    "MB"},
            {"Memory Total",    "MB"}
        };
        string[] infoContainerStr = new string[] {
            "Run on image id",
            "Run on image",
            "Name",
            "Container ID",
            "Status",
            "Connected IP",
            "Gateway",
            "Mac Address"
        };
        string[,] infoIntelX86Val = new string[,] {
            {"CPU Usage",       "%"},
            {"GPU Usage",       "%"},
            {"CPU Temp.",       "Celsius"},
            {"GPU Temp.",       "Celsius"}
        };
        string[] infoIntelX86Str = new string[] {
            "CPU Name",
            "GPU Name"
        };
        ListViewGroup susi4Group;
        public UInt32 SupportEventFlags = 0;

        public bool Available
        {
            get
            {
                if (SusiAIInfo.SusiAIGetCaps(SusiAIInfo.SUSI_ID_AI_SUPPORT_FLAGS, ref SupportEventFlags) == SusiStatus.SUSI_STATUS_SUCCESS)
                    return true;
                else
                    return false;
            }
        }

        public ctlMain()
        {
            try
            {
                UInt32 Status = SusiLib.SusiLibInitialize();

                if (Status != SusiStatus.SUSI_STATUS_SUCCESS && Status != SusiStatus.SUSI_STATUS_INITIALIZED)
                    return;
            }
            catch
            {
                return;
            }

            InitializeComponent();
        }
        private void radioButtonAiList_CheckedChanged(object sender, EventArgs e)
        {
            var radioButton = (RadioButton)sender;

            if (radioButton.Checked == false)
                return;

            timer_monitorAi.Stop();

            listView_AiInfo.Items.Clear();
            listView_AiInfo.Groups.Clear();

            if (radioButton.Name.Contains("Nvidia"))
            {
                GetNVX86Info((UInt32)radioButton.TabIndex);
            }
            else if (radioButton.Name.Contains("Docker"))
            {
                GetDockerImageInfo();
            }
            else if (radioButton.Name.Contains("Containers"))
            {
                GetContainerInfo();
            }
            else if (radioButton.Name.Contains("Intel"))
            {
                GetIntelX86Info();
            }
            timer_monitorAi.Start();
        }
        UInt32 SupportEventFlagsCount = 0;
        public void InitRB(UInt32 index, string names)
        {
            RadioButton radioButtonAiList = new RadioButton();
            radioButtonAiList.AutoSize = true;
            radioButtonAiList.TabIndex = (int)index;
            radioButtonAiList.Text = names;
            radioButtonAiList.Location = new System.Drawing.Point((75 * ((int)SupportEventFlagsCount++)) + 10, 18);
            radioButtonAiList.Name = "RadioButton_" + names + index.ToString();
            radioButtonAiList.Enabled = true;
            if (SupportEventFlagsCount == 1) radioButtonAiList.Checked = true;
            radioButtonAiList.CheckedChanged += new System.EventHandler(this.radioButtonAiList_CheckedChanged);
            groupBox_AiInfoList.Controls.Add(radioButtonAiList);
        }
        private void PageInfo_Load(object sender, EventArgs e)
        {
            UInt32 Status = SusiStatus.SUSI_STATUS_SUCCESS, num = 0;
            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_X86_NV) != 0)
            {
                Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_AI_ID_X86_NV_GET_COUNT, ref num);
                if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                {
                    if (num == 1)
                        InitRB(0, "Nvidia");
                    else
                    {
                        for (UInt32 index = 0; index < num; index++)
                            InitRB(index, String.Format("Nvidia{0}", index));
                    }
                    GetNVX86Info(0);
                }
            }
            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_ARM_NV) != 0)
                InitRB(SupportEventFlagsCount, "Nvidia ARM");
            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_DOCKER_IMG) != 0)
                InitRB(SupportEventFlagsCount, "Docker Image");
            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_CONTAINER) != 0)
                InitRB(SupportEventFlagsCount, "Containers");
            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_X86_INTEL) != 0)
            {
                InitRB(SupportEventFlagsCount, "Intel");
                if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_X86_NV) == 0)
                {
                    GetIntelX86Info();
                }
            }
            if (SupportEventFlags > 0)
                timer_monitorAi.Enabled = true;
        }
        private void GetNVX86Info(UInt32 index)
        {
            UInt32 Status;
            UInt32 Value = 0;
            string tmp_str;
            UInt32 Length = 128;
            StringBuilder sb = new StringBuilder((int)Length);
            string ListViewGroupHeader = "GPU ID ";

            susi4Group = new ListViewGroup(ListViewGroupHeader + index.ToString());
            listView_AiInfo.Groups.Add(susi4Group);
            for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_X86_NV_MAX; i++)
            {
                if ((SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i) == SusiAIInfo.SUSI_AI_ID_X86_NV_GET_COUNT)
                    continue;
                Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE(SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i, index), ref Value);
                if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                {
                    if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_POWER_USAGE)
                        tmp_str = String.Format("{0}", (float)(Value / 100.0));
                    else if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_PERF)
                        tmp_str = String.Format("P{0}", Value);
                    else if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_COMPUTE_MODE)
                        tmp_str = String.Format("{0}", ComputeMode[Value]);
                    else if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_DISPLAY_ACTIVE)
                        tmp_str = String.Format("{0}", DisplayActive[Value]);
                    else
                        tmp_str = String.Format("{0}", Value);
                    ListViewItem lvItem = new ListViewItem(new string[] { infoX86Val[i, 0], tmp_str, infoX86Val[i, 1] }, susi4Group);
                    listView_AiInfo.Items.Add(lvItem);
                }
            }
            for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_X86_NV_STR_MAX; i++)
            {
                Length = 128;
                Status = SusiAIInfo.SusiAIGetStringA(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE(SusiAIInfo.SUSI_ID_MAPPING_GET_NAME_X86_NV_AI(i), index), sb, ref Length);
                if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                {
                    ListViewItem lvItem = new ListViewItem(new string[] { infoX86Str[i], sb.ToString() }, susi4Group);
                    listView_AiInfo.Items.Add(lvItem);
                }
            }
        }

        private void GetIntelX86Info()
        {
            UInt32 Status;
            UInt32 Value = 0;
            UInt32 Length = 128;
            string tmp_str;
            StringBuilder sb = new StringBuilder((int)Length);

            for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_X86_INTEL_MAX; i++)
            {
                Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE + i, ref Value);
                if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                {
                    if (((SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE) || 
                        ((SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_X86_INTEL_GPU_USAGE))
                        tmp_str = String.Format("{0}", (float)(Value / 100.0));
                    else
                        tmp_str = String.Format("{0}", Value);
                    ListViewItem lvItem = new ListViewItem(new string[] { infoIntelX86Val[i, 0], tmp_str, infoIntelX86Val[i, 1] }, susi4Group);
                    listView_AiInfo.Items.Add(lvItem);
                }
            }
            for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_X86_INTEL_STR_MAX; i++)
            {
                Length = 128;
                Status = SusiAIInfo.SusiAIGetStringA(SusiAIInfo.SUSI_ID_MAPPING_GET_NAME_X86_INTEL_AI(i), sb, ref Length);
                if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                {
                    ListViewItem lvItem = new ListViewItem(new string[] { infoIntelX86Str[i], sb.ToString() }, susi4Group);
                    listView_AiInfo.Items.Add(lvItem);
                }
            }
        }
        private void GetDockerImageInfo()
        {
            UInt32 Status;
            UInt32 Value = 0, num = 0;
            string tmp_str;
            UInt32 Length = 128;
            StringBuilder sb = new StringBuilder((int)Length);
            string ListViewGroupHeader = "Docker Image ";

            Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_AI_ID_X86_NV_GET_COUNT, ref num);
            if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
            {
                for (UInt32 index = 0; index < num; index++)
                {
                    susi4Group = new ListViewGroup(ListViewGroupHeader + index.ToString());
                    listView_AiInfo.Groups.Add(susi4Group);
                    for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_DOCKER_IMG_STR_MAX; i++)
                    {
                        Status = SusiAIInfo.SusiAIGetStringA(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE(SusiAIInfo.SUSI_ID_MAPPING_GET_NAME_DOCKER_IMG_AI(i), index), sb, ref Length);
                        if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                        {
                            ListViewItem lvItem = new ListViewItem(new string[] { infoDockerImgStr[i], sb.ToString(), "" }, susi4Group);
                            listView_AiInfo.Items.Add(lvItem);
                        }
                    }
                    for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_DOCKER_IMG_MAX; i++)
                    {
                        Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE((SusiAIInfo.SUSI_AI_ID_DOCKER_IMG_SIZE + i), index), ref Value);
                        if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                        {
                            if ((SusiAIInfo.SUSI_AI_ID_DOCKER_IMG_SIZE + i) == SusiAIInfo.SUSI_AI_ID_DOCKER_IMG_SIZE)
                                tmp_str = String.Format("{0}", (float)(Value / 1000.0));
                            else
                                tmp_str = String.Format("{0}", Value);
                            ListViewItem lvItem = new ListViewItem(new string[] { infoDockerImgVal[i, 0], tmp_str, infoDockerImgVal[i, 1] }, susi4Group);
                            listView_AiInfo.Items.Add(lvItem);
                        }
                    }
                }
            }
        }
        private void GetContainerInfo()
        {
            UInt32 Status;
            UInt32 Value = 0, num = 0;
            string tmp_str;
            UInt32 Length = 128;
            StringBuilder sb = new StringBuilder((int)Length);
            string ListViewGroupHeader = "Container ";

            Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_AI_ID_CONTAINER_COUNT, ref num);
            if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
            {
                for (UInt32 index = 0; index < num; index++)
                {
                    susi4Group = new ListViewGroup(ListViewGroupHeader + index.ToString());
                    listView_AiInfo.Groups.Add(susi4Group);
                    for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_CONTAINER_STR_MAX; i++)
                    {
                        Status = SusiAIInfo.SusiAIGetStringA(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE(SusiAIInfo.SUSI_ID_MAPPING_GET_NAME_CONTAINER_AI(i), index), sb, ref Length);
                        if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                        {
                            ListViewItem lvItem = new ListViewItem(new string[] { infoContainerStr[i], sb.ToString(), "" }, susi4Group);
                            listView_AiInfo.Items.Add(lvItem);
                        }
                    }
                    for (UInt32 i = 0; i < SusiAIInfo.SUSI_AI_ID_CONTAINER_MAX; i++)
                    {
                        Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE((SusiAIInfo.SUSI_AI_ID_CONTAINER_CPU_USAGE + i), index), ref Value);
                        if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                        {
                            if ((SusiAIInfo.SUSI_AI_ID_CONTAINER_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_CONTAINER_MEM_USED)
                                tmp_str = String.Format("{0}", (float)(Value / 1000.0));
                            else if ((SusiAIInfo.SUSI_AI_ID_CONTAINER_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_CONTAINER_MEM_TOTAL)
                                tmp_str = String.Format("{0}", (Value / 1000.0));
                            else if ((SusiAIInfo.SUSI_AI_ID_CONTAINER_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_CONTAINER_COUNT)
                                tmp_str = String.Format("{0}", Value);
                            else
                                tmp_str = String.Format("{0}", (float)(Value / 100.0));
                            ListViewItem lvItem = new ListViewItem(new string[] { infoContainerVal[i, 0], tmp_str, infoContainerVal[i, 1] }, susi4Group);
                            listView_AiInfo.Items.Add(lvItem);
                        }
                    }
                }
            }
        }

        private void RefreshItems()
        {
            UInt32 Status = SusiStatus.SUSI_STATUS_ERROR;
            UInt32 Value = 0, index = 0;
            string tmp_str;
            timer_monitorAi.Stop();

            listView_AiInfo.BeginUpdate();

            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_X86_NV) != 0)
            {
                foreach (ListViewItem lvi in listView_AiInfo.Items)
                {
                    if (lvi.SubItems[0].Text.Equals(infoX86Val[0, 0]))
                        index = Convert.ToUInt32(lvi.SubItems[1].Text);

                    for (uint i = 1; i < SusiAIInfo.SUSI_AI_ID_X86_NV_MAX; i++)
                    {
                        if (lvi.SubItems[0].Text.Equals(infoX86Val[i, 0]))
                        {
                            if ((SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i) == SusiAIInfo.SUSI_AI_ID_X86_NV_POWER_CAP)
                                continue;
                            if ((SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i) == SusiAIInfo.SUSI_AI_ID_X86_NV_MEM_TOTAL)
                                continue;
                            if ((SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i) == SusiAIInfo.SUSI_AI_ID_X86_NV_GET_COUNT)
                                continue;
                            Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_ID_MAPPING_GET_VALUE(SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i, index), ref Value);
                            if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                            {
                                if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_POWER_USAGE)
                                    tmp_str = String.Format("{0}", (float)(Value / 100.0));
                                else if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_PERF)
                                    tmp_str = String.Format("P{0}", Value);
                                else if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_COMPUTE_MODE)
                                    tmp_str = String.Format("{0}", ComputeMode[Value]);
                                else if (SusiAIInfo.SUSI_AI_ID_X86_NV_SN + i == SusiAIInfo.SUSI_AI_ID_X86_NV_DISPLAY_ACTIVE)
                                    tmp_str = String.Format("{0}", DisplayActive[Value]);
                                else
                                    tmp_str = String.Format("{0}", Value);
                                lvi.SubItems[1].Text = tmp_str;
                                break;
                            }
                        }
                    }
                }
            }
            if ((SupportEventFlags & SusiAIInfo.SUSI_AI_FLAG_SUPPORT_X86_INTEL) != 0)
            {
                foreach (ListViewItem lvi in listView_AiInfo.Items)
                {
                    for (uint i = 0; i < 4; i++)
                    {
                        if (lvi.SubItems[0].Text.Equals(infoIntelX86Val[i, 0]))
                        {
                            Status = SusiAIInfo.SusiAIGetValue(SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE + i, ref Value);
                            if (Status == SusiStatus.SUSI_STATUS_SUCCESS)
                            {
                                if (((SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE) ||
                                    ((SusiAIInfo.SUSI_AI_ID_X86_INTEL_CPU_USAGE + i) == SusiAIInfo.SUSI_AI_ID_X86_INTEL_GPU_USAGE))
                                    tmp_str = String.Format("{0}", (float)(Value / 100.0));
                                else
                                    tmp_str = String.Format("{0}", Value);

                                lvi.SubItems[1].Text = tmp_str;
                                break;
                            }
                        }
                    }
                }
            }
            listView_AiInfo.EndUpdate();
            timer_monitorAi.Start();
        }
        private void timer_monitorAi_Tick(object sender, EventArgs e)
        {
            RefreshItems();
        }
    }
}
