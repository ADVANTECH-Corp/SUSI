#pragma once
#define SVN_REVISION 23780
#if (SVN_REVISION==0)
#error Need install command line tool of SVN
#endif
