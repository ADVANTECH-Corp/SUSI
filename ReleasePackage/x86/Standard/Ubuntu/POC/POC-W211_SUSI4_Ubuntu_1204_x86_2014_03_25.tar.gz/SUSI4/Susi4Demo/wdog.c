#include "common.h"

typedef struct
{
	uint32_t unit;
	uint32_t maxDelay;
	uint32_t minDelay;
	uint32_t maxReset;
	uint32_t minReset;
	uint32_t maxEvent;
	uint32_t minEvent;
} WDogInfo, *PWDogInfo;

static WDogInfo info[SUSI_ID_WATCHDOG_MAX];
static int8_t timer[SUSI_ID_WATCHDOG_MAX];

#define SUSIDEMO_WDOG_FUNCTION_MAX	4
static int8_t func[SUSIDEMO_WDOG_FUNCTION_MAX];
enum funcRank{
	funcTimer,
	funcStart,
	funcTrigger,
	funcStop,	
};

#define SUSIDEMO_WDOG_EVENTTYPE_MAX 4
static const char *eventTypeStr[] = {
	"None",
	"IRQ",
	"SCI",
	"Power Button"
};
enum eventTypeRank{
	eventTypeNone,
	eventTypeIRQ,
	eventTypeSCI,
	eventTypePwrBtn,	
};

uint8_t wdog_init(int8_t *pavailable)
{
	uint32_t status, id;
	uint8_t index, i;

	*pavailable = 0;

	index = 0;
	for (i = 0; i < SUSI_ID_WATCHDOG_MAX; i++)
	{
		id = i;
		status = SusiWDogGetCaps(id, SUSI_ID_WDT_UNIT_MINIMUM, &info[i].unit);

		if (status != SUSI_STATUS_SUCCESS)
			continue;

		SusiWDogGetCaps(id, SUSI_ID_WDT_DELAY_MAXIMUM, &info[i].maxDelay);
		SusiWDogGetCaps(id, SUSI_ID_WDT_DELAY_MINIMUM, &info[i].minDelay);
		SusiWDogGetCaps(id, SUSI_ID_WDT_RESET_MAXIMUM, &info[i].maxReset);
		SusiWDogGetCaps(id, SUSI_ID_WDT_RESET_MINIMUM, &info[i].minReset);
		SusiWDogGetCaps(id, SUSI_ID_WDT_EVENT_MAXIMUM, &info[i].maxEvent);
		SusiWDogGetCaps(id, SUSI_ID_WDT_EVENT_MINIMUM, &info[i].minEvent);

		timer[index] = i;
		index++;
	}

	if (index == 0)
		return 0;
		
	for (i = index; i < SUSI_ID_WATCHDOG_MAX; i++)
		timer[i] = -1;

	*pavailable = 1;

	func[funcTimer] = funcTimer;
	func[funcStart] = funcStart;
	func[funcTrigger] = funcTrigger;
	func[funcStop] = funcStop;

	return 0;
}

static void show_information(int iTimer)
{
	printf("\nMinimum Unit: %u ms\n", info[iTimer].unit);
	//printf("Delay Time: %u ~ %u ms\n", info[iTimer].minDelay, info[iTimer].maxDelay);
	//printf("Reset Time: %u ~ %u ms\n", info[iTimer].minReset, info[iTimer].maxReset);
	//if (info[iTimer].maxEvent == 0)
	//	printf("Event Time: %u ~ %u ms\n", info[iTimer].minEvent, info[iTimer].maxEvent);	
}

static uint8_t title(uint8_t iTimer)
{
	printf("**********************************************\n");
	printf("**               SUSI4.0 demo               **\n");
	printf("**********************************************\n");

	if (iTimer >= SUSI_ID_WATCHDOG_MAX)
	{
		printf("ERROR: The watchdog timer is not exist.\n");
		return 1;
	}

	printf("\nWatchdog %u\n\n", iTimer + 1);

	return 0;
}

static uint8_t select_timer(uint8_t *piTimer)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("\nWatchdog Timer:\n");
	for (i = 0; i < SUSI_ID_WATCHDOG_MAX && timer[i] > -1; i++)
	{
		if (timer[i] == *piTimer)
			printf("%u) [Watchdog %d]\n", i, timer[i] + 1);
		else
			printf("%u) Watchdog %d\n", i, timer[i] + 1);
	}

	if (i == 1)
	{
		*piTimer = timer[0];
		printf("Only Watchdog %u is available.\n", *piTimer);
		printf("\nPress ENTER to continue. ");
		wait_enter();
		return 0;
	}

	tmp_u32 = 0;
	do {
		printf("\nEnter your choice (0 to %u): ", i - 1);
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*piTimer = timer[tmp_u32];

	return 0;
}

static void SUSI_API show_callback(void* context)
{
	printf("\n================\n=Get IRQ Event!=\n================\n");
}

static uint8_t start_watchdog(uint32_t wdog_id, WDogInfo info)
{
	uint32_t status, delayTime, eventType, eventTime, resetTime, tmp_u32;
	uint8_t i;

	printf("\nStart Watchdog:\n");

	tmp_u32 = 0;
	do {
		printf("\nDelay Time (%u to %u ms): ", info.minDelay, info.maxDelay);
	} while (input_uint(&tmp_u32, 10, info.maxDelay, info.minDelay));

	delayTime = tmp_u32 - (tmp_u32 % info.unit);
	if (delayTime != tmp_u32)
		printf("Since the unit is %u, your input transfer to %u.\n", info.unit, delayTime);

	eventType = SUSI_WDT_EVENT_TYPE_NONE;
	if (info.maxEvent > 0)
	{
		
		printf("\nEvent Type:\n");
		for (i = 0; i < SUSIDEMO_WDOG_EVENTTYPE_MAX; i++)
			printf("%u) %s\n", i, eventTypeStr[i]);

		do {
			printf("\nEnter your choice: ");
		} while (input_uint(&tmp_u32, 10, SUSIDEMO_WDOG_EVENTTYPE_MAX - 1, 0));

		switch (tmp_u32)
		{
		case eventTypeNone:
			eventType = SUSI_WDT_EVENT_TYPE_NONE;
			break;

		case eventTypeIRQ:
			eventType = SUSI_WDT_EVENT_TYPE_IRQ;
			break;

		case eventTypeSCI:
			eventType = SUSI_WDT_EVENT_TYPE_SCI;
			break;

		case eventTypePwrBtn:
			eventType = SUSI_WDT_EVENT_TYPE_PWRBTN;
			break;
		}
	}

	eventTime = 0;
	if (eventType != SUSI_WDT_EVENT_TYPE_NONE)
	{
		do {
			printf("\nEvent Time (%u to %u ms): ", info.minEvent, info.maxEvent);
		} while (input_uint(&tmp_u32, 10, info.maxEvent, info.minEvent));

		eventTime = tmp_u32 - (tmp_u32 % info.unit);
		if (eventTime != tmp_u32)
			printf("Since the unit is %u, your input transfer to %u.\n", info.unit, eventTime);
	}

	do {
		printf("\nReset Time (%u to %u ms): ", info.minReset, info.maxReset);
	} while (input_uint(&tmp_u32, 10, info.maxReset, info.minReset));

	resetTime = tmp_u32 - (tmp_u32 % info.unit);
	if (resetTime != tmp_u32)
		printf("Since the unit is %u, your input transfer to %u.\n", info.unit, resetTime);

	if (eventType == SUSI_WDT_EVENT_TYPE_IRQ && eventTime > 0)
		SusiWDogSetCallBack(wdog_id, (SUSI_WDT_INT_CALLBACK)&show_callback, NULL);

	status = SusiWDogStart(wdog_id, delayTime, eventTime, resetTime, eventType);

	if (status != SUSI_STATUS_SUCCESS)
	{
		if (status == SUSI_STATUS_RUNNING)
			printf("Watchdog is running. (0x%08X)\n", status);
		else if (status == SUSI_STATUS_UNSUPPORTED)
			printf("Unsupported the function. (0x%08X)\n", status);
		else
			printf("SusiWDogStart() failed. (0x%08X)\n", status);

		return 1;
	}

	printf("SusiWDogStart() succeed.\n");
	
	return 0;
}

static uint8_t trigger_watchdog(uint32_t wdog_id)
{
	uint32_t status;

	printf("\nTrigger Watchdog:\n");

	status = SusiWDogTrigger(wdog_id);
	if (status != SUSI_STATUS_SUCCESS)
	{
		printf("SusiWDogTrigger() failed. (0x%08X)\n", status);
		return 1;
	}

	printf("SusiWDogTrigger() succeed.\n");
	return 0;
}

static uint8_t stop_watchdog(uint32_t wdog_id)
{
	uint32_t status;

	printf("\nStop Watchdog:\n");

	status = SusiWDogStop(wdog_id);
	if (status != SUSI_STATUS_SUCCESS)
	{
		printf("SusiWDogStop() failed. (0x%08X)\n", status);
		return 1;
	}

	printf("SusiWDogStop() succeed.\n");
	return 0;
}



static uint8_t show_menu(uint8_t iTimer)
{
	printf("0) Back to Main menu\n");	
	printf("1) Select watchdog timer\n");
	printf("2) Start\n");
	printf("3) Trigger\n");
	printf("4) Stop\n");
	printf("\nSelect the item you want to do: ");

	return 0;
}

uint8_t wdog_main(void)
{
	int32_t op;
	uint32_t wdog_id;
	uint8_t iTimer, result;

	iTimer = timer[0];
	wdog_id = iTimer;
	
	for (;;)
	{
		clr_screen();
		if (title(iTimer) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (show_menu(iTimer) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op == 0)
		{
			clr_screen();
			break;
		}

		if (op < 1 || op > SUSIDEMO_WDOG_FUNCTION_MAX)
		{
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			continue;
		}

		switch (func[op - 1])
		{
		case funcTimer:
			result = select_timer(&iTimer);
			wdog_id = iTimer;
			break;

		case funcStart:
			show_information(iTimer);
			result = start_watchdog(wdog_id, info[iTimer]);
			break;

		case funcTrigger:
			result = trigger_watchdog(wdog_id);
			break;

		case funcStop:
			result = stop_watchdog(wdog_id);
			break;

		default:
			result = 1;
			printf("Unknown choice!\n");
			break;
		}

		if (result != 0  || func[op - 1] != funcTimer)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}

	clr_screen();

	return 0;
}