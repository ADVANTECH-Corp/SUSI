#!/usr/bin/env bash 
 
 
systemctl stop susi_api_server.service


mkdir -p /etc/Advantech/susi/service

mkdir -p /opt/Advantech/susi/service

rm -rf   /opt/Advantech/susi/service/*

 
cp Susi_X86_64_Service exeSusiService.sh   /opt/Advantech/susi/service


cp susi_api_server.service /etc/systemd/system/

 
systemctl daemon-reload
systemctl enable susi_api_server
systemctl start susi_api_server










