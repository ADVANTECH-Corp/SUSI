#include "common.h"

static const char *hostStr[] = {
	"External",
	"OEM0",
	"OEM1",
	"OEM2",
	"OEM3"
};

#define SUSIDEMO_ADDRESS_TYPE_MAX 2

enum addrTypeRank{
	addr_7bit,
	addr_10bit
};

#define SUSIDEMO_COMMAND_TYPE_MAX 3

enum cmdTypeRank{
	cmd_byte,
	cmd_word,
	cmd_none
};

static int host[SUSI_I2C_MAX_DEVICE];

#define SUSIDEMO_I2C_FUNCTION_MAX	7
static int8_t func[SUSIDEMO_I2C_FUNCTION_MAX];
enum funcRank{
	funcHost,
	funcProbe,
	funcRead,
	funcWrite,
	funcWtRd,
	funcGetFreq,
	funcSetFreq
};

typedef struct {
	uint32_t addrType;
	uint32_t addr;
	uint32_t cmdType;
	uint32_t cmd;
	uint32_t writeLength;
	uint32_t readLength;
} I2CParameter, *PI2CParameter;

#define SUSIDEMO_I2C_PARAMETER_MAX	5
static int8_t para[SUSIDEMO_I2C_PARAMETER_MAX];
enum paraRank{
	paraAddr,
	paraCmd,
	paraWtLen,
	paraRdLen,
	paraRun
};

uint8_t iic_init(int8_t *pavailable)
{
	uint32_t status, supFlag;
	uint8_t index, i;

	*pavailable = 0;

	status = SusiBoardGetValue(SUSI_ID_I2C_SUPPORTED, &supFlag);
	if (status != SUSI_STATUS_SUCCESS)
	{
		printf("SusiBoardGetValue() failed. (0x%08X)\n", status);
		*pavailable = 0;
		return 1;
	}

	if (supFlag == 0)
	{
		*pavailable = 0;
		return 0;
	}

	index = 0;
    for (i = 0; i < SUSI_I2C_MAX_DEVICE; i++)
    {
        if ((supFlag & (1 << i)) > 0)
        {
			host[index] = i;
			index++;
        }
    }
	
	for (i = index; i < SUSI_I2C_MAX_DEVICE; i++)
		host[i] = -1;

	*pavailable = 1;

	func[funcHost] = funcHost;
	func[funcProbe] = funcProbe;
	func[funcRead] = funcRead;
	func[funcWrite] = funcWrite;
	func[funcWtRd] = funcWtRd;
	func[funcGetFreq] = funcGetFreq;
	func[funcSetFreq] = funcSetFreq;

	return 0;
}

static uint8_t title(uint8_t iHost)
{
	printf("**********************************************\n");
	printf("**               SUSI4.0 demo               **\n");
	printf("**********************************************\n");

	if (iHost >= SUSI_I2C_MAX_DEVICE)
	{
		printf("ERROR: The I2C host is not exist.\n");
		return 1;
	}

	printf("\nI2C Host: %s\n\n", hostStr[iHost]);

	return 0;
}

static uint8_t select_host(uint8_t *piHost)
{
	uint32_t tmp_u32;
	uint8_t i;

	printf("\nI2C Host:\n");
	for (i = 0; i < SUSI_I2C_MAX_DEVICE && host[i] > -1; i++)
	{
		if (host[i] == *piHost)
			printf("%u) [Host %s]\n", i, hostStr[host[i]]);
		else
			printf("%u) Host %s\n", i, hostStr[host[i]]);
	}

	if (i == 1)
	{
		*piHost = host[0];
		printf("Only Host %s is available.\n", hostStr[*piHost]);
		printf("\nPress ENTER to continue. ");
		wait_enter();
		return 0;
	}

	tmp_u32 = 0;
	do {		
		printf("\nEnter your choice (0 to %u): ", i - 1);
	} while (input_uint(&tmp_u32, 10, i - 1, 0) != 0);

	*piHost = host[tmp_u32];

	return 0;
}

static uint8_t probe_address(uint32_t iic_id)
{
	uint32_t status, addrType, convAddr;
	uint8_t numItem;
	uint16_t i;

	printf("Address Type:\n");
	printf("0) 7-bit\n");
	printf("1) 10-bit\n");

	do {
		printf("\nEnter your choice: ");
	} while (input_uint(&addrType, 10, 2, 0) != 0);

	printf("\nProbe:\n");

	numItem = 0;
	switch (addrType)
	{
	case addr_7bit:
		for (i = 0; i < 0x7F; i++)
		{
			convAddr = SUSI_I2C_ENC_7BIT_ADDR(i);
			status = SusiI2CProbeDevice(iic_id, convAddr);
			if (status == SUSI_STATUS_SUCCESS)
			{
				printf("%02X ", convAddr);
				numItem++;
			}
		}

		if (numItem == 0)
		{
			printf("Fine no device of 7-bit address.\n");
			return 1;
		}

		printf("\n");
		break;

	case addr_10bit:
		for (i = 0; i < 0x3FF; i++)
		{
			convAddr = SUSI_I2C_ENC_10BIT_ADDR(i);
			status = SusiI2CProbeDevice(iic_id, convAddr);
			if (status == SUSI_STATUS_SUCCESS)
			{			
				printf("%04X ", i);
				numItem++;
			}
		}

		if (numItem == 0)
		{
			printf("Fine no device of 10-bit address.\n");
			return 1;
		}

		printf("\n");
		break;

	default:
		return 1;
	}

	return 0;
}

static uint8_t read_data(uint32_t iic_id, I2CParameter iicPara)
{
	uint32_t status;
	uint8_t *pdataBuffer, i;
	
	pdataBuffer = 0;

	if (iicPara.readLength > 0)
		pdataBuffer = (uint8_t*)malloc(iicPara.readLength * sizeof(uint8_t));

    status = SusiI2CReadTransfer(iic_id, iicPara.addr, iicPara.cmd, pdataBuffer, iicPara.readLength);
    if (status != SUSI_STATUS_SUCCESS)
    {
		if (pdataBuffer > 0)
			free(pdataBuffer);

		printf("Read transfer failed. (0x%08X)\n", status); 
		return 1;
    }

	printf("Read Data (Hex):\n");
	for (i = 0; i < iicPara.readLength; i++)
		printf(" %02X", pdataBuffer[i]);
	printf("\n\n");

	if (pdataBuffer > 0)
		free(pdataBuffer);

	return 0;
}

static uint8_t write_data(uint32_t iic_id, I2CParameter iicPara)
{
	uint32_t status;
	uint8_t *pdataBuffer, i;

	pdataBuffer = 0;

	if (iicPara.writeLength > 0)
	{
		pdataBuffer = (uint8_t*)malloc((iicPara.writeLength) * sizeof(uint8_t));

		printf("\nInput %u-byte value (Hex):\n ", iicPara.writeLength);
		if (input_byte_sequence(pdataBuffer, iicPara.writeLength, NULL, 16, 0xFF, 0) != 0)
		{
			if (pdataBuffer > 0)
				free(pdataBuffer);

			printf("Input invalid value.\n");
			return 1;
		}

		printf("\n\nWrite Data (Hex):\n");
		for (i = 0; i < iicPara.writeLength; i++)
			printf(" %02X", pdataBuffer[i]);
		printf("\n\n");
	}

    status = SusiI2CWriteTransfer(iic_id, iicPara.addr, iicPara.cmd, pdataBuffer, iicPara.writeLength);
	
	if (pdataBuffer > 0)
		free(pdataBuffer);

    if (status != SUSI_STATUS_SUCCESS)
	{		
		printf("Write transfer failed. (0x%08X)\n", status);
		return 1;
	}

	printf("Write transfer succeed.\n");

	return 0;
}

static uint8_t write_read_data(uint32_t iic_id, I2CParameter iicPara)
{
	uint32_t status; 
	uint8_t *pwriteBuffer, *preadBuffer, i;

	pwriteBuffer = 0;
	preadBuffer = 0;

	if (iicPara.writeLength > 0)
	{
		pwriteBuffer = (uint8_t*)malloc(iicPara.writeLength * sizeof(uint8_t));

		printf("\nInput %u-byte value (Hex):\n ", iicPara.writeLength);
		if (input_byte_sequence(pwriteBuffer, iicPara.writeLength, NULL, 16, 0xFF, 0) != 0)
		{
			if (pwriteBuffer)
				free(pwriteBuffer);

			printf("Input invalid value.\n");
			return 1;
		}

		printf("\nWrite Data (Hex):\n");
		for (i = 0; i < iicPara.writeLength; i++)
			printf(" %02X", pwriteBuffer[i]);
		printf("\n\n");
	}

	if (iicPara.readLength > 0)
		preadBuffer = (uint8_t*)malloc(iicPara.readLength * sizeof(uint8_t));

	status = SusiI2CWriteReadCombine(iic_id, iicPara.addr, pwriteBuffer, iicPara.writeLength, preadBuffer, iicPara.readLength);
    if (status != SUSI_STATUS_SUCCESS)
    {
		if (pwriteBuffer > 0)
			free(pwriteBuffer);

		if (preadBuffer > 0)
			free(preadBuffer);

		printf("Write&Read combine failed. (0x%08X)\n", status);		
		return 1;
    }

	if (pwriteBuffer > 0)
		free(pwriteBuffer);

	if (preadBuffer > 0)
	{
		printf("Data (Hex):");
		for (i = 0; i < iicPara.readLength; i++)
			printf(" %02X", preadBuffer[i]);
		printf("\n\n");

		free(preadBuffer);
	}
	else
	{
		printf("Write&Read combine succeed.\n");
	}

	return 0;
}

static uint8_t get_frequency(uint32_t iic_id, uint32_t *pgetFreq)
{
	uint32_t status;

	*pgetFreq = 0;

    status = SusiI2CGetFrequency(iic_id, pgetFreq);
    if (status != SUSI_STATUS_SUCCESS)
    {
        //printf("Get no frequency. (0x%08X)\n", status);
		return 1;
    }

	//printf("Frequency = %u\n", *pgetFreq);

	return 0;
}

static uint8_t set_frequency(uint32_t iic_id)
{
	uint32_t status, setVal, tmp_u32;

	printf("Frequency Range:\n");
	printf("0) 1 to 100 kHz\n");
	printf("1) 400 kHz\n");
	
	tmp_u32 = 0;
	do {
		printf("\nEnter your choice: ");
	} while (input_uint(&tmp_u32, 10, 1, 0) != 0);

	if (tmp_u32 == 0)
	{
		do {
			printf("Frequency (1 to 100 kHz) = ");
		} while (input_uint(&tmp_u32, 10, 100, 1) != 0);

		setVal = tmp_u32;
	}
	else
	{
		setVal = 400;
	}

    status = SusiI2CSetFrequency(iic_id, setVal);
    if (status != SUSI_STATUS_SUCCESS)
    {
        printf("SusiI2CSetFrequency() failed. (0x%08X)\n", status);
		return 1;
    }

	printf("SusiI2CSetFrequency() succeed.\n");

	return 0;
}

static uint8_t show_menu_write_read(int8_t iFunc, I2CParameter iicPara)
{
	uint8_t i;

	switch (iFunc)
	{
	case funcRead:
		printf("Read Data:\n\n");
		break;
	case funcWrite:
		printf("Write Data:\n\n");
		break;
	case funcWtRd:
		printf("Write and Read Data:\n\n");
		break;
	default:
		return 1;
	}

	i = 0;

	if (iicPara.addrType == addr_7bit)
		printf("%u) Slave Address: 0x%02X (7-bit)\n", i, iicPara.addr);
	else
		printf("%u) Slave Address: 0x%04X (10-bit)\n", i, iicPara.addr);
	para[i] = paraAddr;
	i++;

	if (iFunc != funcWtRd)
	{
		switch (iicPara.cmdType)
		{
		case cmd_byte:
			printf("%u) Command: 0x%02X (Byte-type)\n", i, iicPara.cmd);
			break;
		case cmd_word:
			printf("%u) Command: 0x%04X (Word-type)\n", i, iicPara.cmd);
			break;
		case cmd_none:
			printf("%u) Command: None\n", i);
			break;
		}
		para[i] = paraCmd;
		i++;
	}

	if (iFunc == funcWrite || iFunc == funcWtRd)
	{
		printf("%u) Write Data Length: %u\n", i, iicPara.writeLength);
		para[i] = paraWtLen;
		i++;
	}

	if (iFunc == funcRead || iFunc == funcWtRd)
	{
		printf("%u) Read Data Length: %u\n", i, iicPara.readLength);
		para[i] = paraRdLen;
		i++;
	}

	printf("%u) Run\n", i);
	para[i] = paraRun;
	i++;

	while (i < SUSIDEMO_I2C_PARAMETER_MAX)
	{
		para[i] = -1;
		i++;
	}

	printf("\nEnter your choice: ");

	return 0;
}

static uint8_t iic_loop_write_read(uint8_t iHost, uint8_t iFunc, PI2CParameter piicPara)
{
	int32_t op;

	piicPara->addrType = addr_7bit;
	piicPara->addr = 0;
	piicPara->cmdType = cmd_byte;
	piicPara->cmd = 0;
	piicPara->writeLength = 1;
	piicPara->readLength = 0;

	for (;;)
	{
		clr_screen();
		if (title(iHost) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (show_menu_write_read(iFunc, *piicPara) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op < 0 || op > SUSIDEMO_I2C_PARAMETER_MAX)
		{
			printf("Unknown choice!\n");
			return 1;
		}

		switch (para[op])
		{
		case paraAddr:
			if (iFunc == funcWtRd)
			{
				piicPara->addrType = addr_7bit;
			}
			else
			{
				printf("Address Type:\n");
				printf("0) 7-bit\n");
				printf("1) 10-bit\n");
				
				do {
					printf("\nEnter your choice: ");
				} while (input_uint(&piicPara->addrType, 10, 2, 0) != 0);
			}

			if (piicPara->addrType == addr_7bit)
			{
				do {
					printf("7-bit Slave Address: 0x");
				} while (input_uint(&piicPara->addr, 16, 0xFF, 0) != 0);
			}
			else
			{
				do {
					printf("10-bit Slave Address: 0x");
				} while (input_uint(&piicPara->addr, 16, 0x3FF, 0) != 0);
			}
			break;

		case paraCmd:
			if (iFunc != funcWtRd)
			{
				printf("Command Type:\n");
				printf("0) Byte\n");
				printf("1) Word\n");
				printf("2) None\n");
				
				do {
					printf("\nEnter your choice: ");
				} while (input_uint(&piicPara->cmdType, 10, 3, 0) != 0);

				if (piicPara->cmdType == cmd_byte)
				{
					do {
						printf("\nBtye Command: 0x");
					} while (input_uint(&piicPara->cmd, 16, 0xFF, 0) != 0);
				}
				else if (piicPara->cmdType == cmd_word)
				{
					do {
						printf("\nWord Command: 0x");
					} while (input_uint(&piicPara->cmd, 16, 0xFFFF, 0) != 0);
				}
			}			
			break;

		case paraWtLen:
			do {
				printf("\nWrite Length (%u to %u): ", 0x00, 0x20);
			} while (input_uint(&piicPara->writeLength, 10, 0x20, 0) != 0);
			break;

		case paraRdLen:
			do {
				printf("\nRead Length (%u to %u): ", 0x00, 0x20);
			} while (input_uint(&piicPara->readLength, 10, 0x20, 0) != 0);
			break;

		case paraRun:
			if (piicPara->addrType == addr_10bit)
				piicPara->addr = SUSI_I2C_ENC_EXT_CMD(piicPara->addr);

			if (piicPara->cmdType == cmd_word)
				piicPara->cmd = SUSI_I2C_ENC_EXT_CMD(piicPara->cmd);
			else if (piicPara->cmdType == cmd_none)
				piicPara->cmd = SUSI_I2C_NO_CMD;

			return 0;

		default:
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}
	}

	return 1;
}

static uint8_t show_menu(uint32_t getFreq)
{
	printf("0) Back to Main menu\n");
	printf("1) Select I2C host\n");	
	printf("2) Probe\n");
	printf("3) Read\n");
	printf("4) Write\n");
	printf("5) WR Combined\n");

	if (func[funcGetFreq] > 0 && func[funcSetFreq] > 0)
	{
		printf("6) Get/Refresh Frequency: %u kHz\n", getFreq);
		printf("7) Set Frequency\n");
	}

	printf("\nSelect the item you want to do: ");

	return 0;
}

uint8_t iic_main(void)
{
	int32_t op;
	uint32_t iic_id, getFreq;
	uint8_t result, iHost;
	I2CParameter iic_para;

	result = 0;

	iHost = host[0];
	iic_id = iHost;

	iic_para.addrType = 0;
	iic_para.addr = 0;
	iic_para.cmdType = 0;
	iic_para.cmd = 0;
	iic_para.writeLength = 0;
	iic_para.readLength = 0;

	for (;;)
	{
		clr_screen();
		if (title(iHost) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (get_frequency(iic_id, &getFreq) != 0)
		{
			func[funcGetFreq] = -1;
			func[funcSetFreq] = -1;
		}

		if (show_menu(getFreq) != 0)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
			break;
		}

		if (SCANF_IN("%d", &op) <= 0)
			op = -1;

		wait_enter();

		if (op == 0)
		{
			clr_screen();
			break;
		}

		if (op < 1 || op > SUSIDEMO_I2C_FUNCTION_MAX)
		{
			printf("Unknown choice!\n");
			printf("\nPress ENTER to continue. ");
			wait_enter();
			continue;
		}

		switch (func[op - 1])
		{
		case funcHost:
			result = select_host(&iHost);
			if (result == 0)
				iic_id = iHost;
			break;

		case funcProbe:
			result = probe_address(iic_id);
			break;

		case funcRead:
			if (iic_loop_write_read(iHost, funcRead, &iic_para) == 0)
				result = read_data(iic_id, iic_para);
			break;

		case funcWrite:
			if (iic_loop_write_read(iHost, funcWrite, &iic_para) == 0)
				result = write_data(iic_id, iic_para);
			break;

		case funcWtRd:
			if (iic_loop_write_read(iHost, funcWtRd, &iic_para) == 0)
				result = write_read_data(iic_id, iic_para);
			break;

		case funcGetFreq:
			result = get_frequency(iic_id, &getFreq);
			break;

		case funcSetFreq:
			result = set_frequency(iic_id);
			break;

		default:
			result = 1;
			printf("Unknown choice!\n");
			break;
		}

		if (result != 0 || func[op - 1] != funcHost)
		{
			printf("\nPress ENTER to continue. ");
			wait_enter();
		}
	}

	clr_screen();

	return 0;
}
