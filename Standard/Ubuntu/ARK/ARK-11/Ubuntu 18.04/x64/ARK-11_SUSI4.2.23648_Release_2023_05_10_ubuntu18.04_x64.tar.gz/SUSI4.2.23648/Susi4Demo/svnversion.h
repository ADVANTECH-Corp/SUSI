#ifndef __SVN_REVISION_H__
#define __SVN_REVISION_H__
#define SVN_REVISION 23648
#endif /* __SVN_REVISION_H__ */
