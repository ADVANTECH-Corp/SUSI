﻿namespace Susi4.Plugin
{
	partial class ctlMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_EC = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label_ATTF = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label_RC = new System.Windows.Forms.Label();
            this.label_ATTE_text = new System.Windows.Forms.Label();
            this.label_ATTE = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label_SoH = new System.Windows.Forms.Label();
            this.label_Manu = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label_SN = new System.Windows.Forms.Label();
            this.label_DV = new System.Windows.Forms.Label();
            this.label_MD = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label_ASC = new System.Windows.Forms.Label();
            this.label_CC = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_RSC = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label_FCC = new System.Windows.Forms.Label();
            this.label_BS = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label_Cur = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label_DC = new System.Windows.Forms.Label();
            this.label_Vol = new System.Windows.Forms.Label();
            this.label_Temp = new System.Windows.Forms.Label();
            this.timer_SBS = new System.Windows.Forms.Timer(this.components);
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_EC);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label_ATTF);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label_RC);
            this.groupBox2.Controls.Add(this.label_ATTE_text);
            this.groupBox2.Controls.Add(this.label_ATTE);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label_SoH);
            this.groupBox2.Controls.Add(this.label_Manu);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label_SN);
            this.groupBox2.Controls.Add(this.label_DV);
            this.groupBox2.Controls.Add(this.label_MD);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label_ASC);
            this.groupBox2.Controls.Add(this.label_CC);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label_RSC);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label_FCC);
            this.groupBox2.Controls.Add(this.label_BS);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label_Cur);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label_DC);
            this.groupBox2.Controls.Add(this.label_Vol);
            this.groupBox2.Controls.Add(this.label_Temp);
            this.groupBox2.Location = new System.Drawing.Point(18, 14);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(498, 267);
            this.groupBox2.TabIndex = 65;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "General Information";
            // 
            // label_EC
            // 
            this.label_EC.AutoSize = true;
            this.label_EC.Location = new System.Drawing.Point(152, 202);
            this.label_EC.Name = "label_EC";
            this.label_EC.Size = new System.Drawing.Size(13, 12);
            this.label_EC.TabIndex = 73;
            this.label_EC.Text = "--";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 202);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 72;
            this.label14.Text = "Error Codes:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 160);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 12);
            this.label13.TabIndex = 70;
            this.label13.Text = "Average Time To Full:";
            // 
            // label_ATTF
            // 
            this.label_ATTF.AutoSize = true;
            this.label_ATTF.Location = new System.Drawing.Point(152, 160);
            this.label_ATTF.Name = "label_ATTF";
            this.label_ATTF.Size = new System.Drawing.Size(13, 12);
            this.label_ATTF.TabIndex = 71;
            this.label_ATTF.Text = "--";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(285, 123);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 12);
            this.label8.TabIndex = 68;
            this.label8.Text = "Remaining Capacity:";
            // 
            // label_RC
            // 
            this.label_RC.AutoSize = true;
            this.label_RC.Location = new System.Drawing.Point(418, 123);
            this.label_RC.Name = "label_RC";
            this.label_RC.Size = new System.Drawing.Size(13, 12);
            this.label_RC.TabIndex = 69;
            this.label_RC.Text = "--";
            // 
            // label_ATTE_text
            // 
            this.label_ATTE_text.AutoSize = true;
            this.label_ATTE_text.Location = new System.Drawing.Point(16, 181);
            this.label_ATTE_text.Name = "label_ATTE_text";
            this.label_ATTE_text.Size = new System.Drawing.Size(124, 12);
            this.label_ATTE_text.TabIndex = 66;
            this.label_ATTE_text.Text = "Average Time To Empty:";
            // 
            // label_ATTE
            // 
            this.label_ATTE.AutoSize = true;
            this.label_ATTE.Location = new System.Drawing.Point(152, 181);
            this.label_ATTE.Name = "label_ATTE";
            this.label_ATTE.Size = new System.Drawing.Size(13, 12);
            this.label_ATTE.TabIndex = 67;
            this.label_ATTE.Text = "--";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 12);
            this.label6.TabIndex = 62;
            this.label6.Text = "SoH:";
            // 
            // label_SoH
            // 
            this.label_SoH.AutoSize = true;
            this.label_SoH.Location = new System.Drawing.Point(152, 141);
            this.label_SoH.Name = "label_SoH";
            this.label_SoH.Size = new System.Drawing.Size(13, 12);
            this.label_SoH.TabIndex = 63;
            this.label_SoH.Text = "--";
            // 
            // label_Manu
            // 
            this.label_Manu.AutoSize = true;
            this.label_Manu.Location = new System.Drawing.Point(152, 49);
            this.label_Manu.Name = "label_Manu";
            this.label_Manu.Size = new System.Drawing.Size(13, 12);
            this.label_Manu.TabIndex = 61;
            this.label_Manu.Text = "--";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 12);
            this.label4.TabIndex = 60;
            this.label4.Text = "Manufacturer Name:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(285, 160);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 12);
            this.label11.TabIndex = 41;
            this.label11.Text = "Temperature:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 12);
            this.label1.TabIndex = 28;
            this.label1.Text = "Serial Number:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(285, 68);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 12);
            this.label17.TabIndex = 58;
            this.label17.Text = "Design Voltage:";
            // 
            // label_SN
            // 
            this.label_SN.AutoSize = true;
            this.label_SN.Location = new System.Drawing.Point(152, 87);
            this.label_SN.Name = "label_SN";
            this.label_SN.Size = new System.Drawing.Size(13, 12);
            this.label_SN.TabIndex = 33;
            this.label_SN.Text = "--";
            // 
            // label_DV
            // 
            this.label_DV.AutoSize = true;
            this.label_DV.Location = new System.Drawing.Point(418, 68);
            this.label_DV.Name = "label_DV";
            this.label_DV.Size = new System.Drawing.Size(13, 12);
            this.label_DV.TabIndex = 59;
            this.label_DV.Text = "--";
            // 
            // label_MD
            // 
            this.label_MD.AutoSize = true;
            this.label_MD.Location = new System.Drawing.Point(152, 68);
            this.label_MD.Name = "label_MD";
            this.label_MD.Size = new System.Drawing.Size(13, 12);
            this.label_MD.TabIndex = 29;
            this.label_MD.Text = "--";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(285, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 12);
            this.label12.TabIndex = 55;
            this.label12.Text = "Cycle Count:";
            // 
            // label_ASC
            // 
            this.label_ASC.AutoSize = true;
            this.label_ASC.Location = new System.Drawing.Point(152, 123);
            this.label_ASC.Name = "label_ASC";
            this.label_ASC.Size = new System.Drawing.Size(13, 12);
            this.label_ASC.TabIndex = 30;
            this.label_ASC.Text = "--";
            // 
            // label_CC
            // 
            this.label_CC.AutoSize = true;
            this.label_CC.Location = new System.Drawing.Point(418, 141);
            this.label_CC.Name = "label_CC";
            this.label_CC.Size = new System.Drawing.Size(13, 12);
            this.label_CC.TabIndex = 56;
            this.label_CC.Text = "--";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 12);
            this.label2.TabIndex = 31;
            this.label2.Text = "Manufacture Date:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 12);
            this.label7.TabIndex = 51;
            this.label7.Text = "Relative State Of Charge:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 12);
            this.label3.TabIndex = 32;
            this.label3.Text = "Absolute State Of Charge:";
            // 
            // label_RSC
            // 
            this.label_RSC.AutoSize = true;
            this.label_RSC.Location = new System.Drawing.Point(152, 104);
            this.label_RSC.Name = "label_RSC";
            this.label_RSC.Size = new System.Drawing.Size(13, 12);
            this.label_RSC.TabIndex = 52;
            this.label_RSC.Text = "--";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(285, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 12);
            this.label9.TabIndex = 39;
            this.label9.Text = "Full Charge Capacity:";
            // 
            // label_FCC
            // 
            this.label_FCC.AutoSize = true;
            this.label_FCC.Location = new System.Drawing.Point(418, 104);
            this.label_FCC.Name = "label_FCC";
            this.label_FCC.Size = new System.Drawing.Size(13, 12);
            this.label_FCC.TabIndex = 38;
            this.label_FCC.Text = "--";
            // 
            // label_BS
            // 
            this.label_BS.AutoSize = true;
            this.label_BS.Location = new System.Drawing.Point(152, 30);
            this.label_BS.Name = "label_BS";
            this.label_BS.Size = new System.Drawing.Size(13, 12);
            this.label_BS.TabIndex = 37;
            this.label_BS.Text = "--";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(285, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 12);
            this.label16.TabIndex = 46;
            this.label16.Text = "Current:";
            // 
            // label_Cur
            // 
            this.label_Cur.AutoSize = true;
            this.label_Cur.Location = new System.Drawing.Point(418, 49);
            this.label_Cur.Name = "label_Cur";
            this.label_Cur.Size = new System.Drawing.Size(13, 12);
            this.label_Cur.TabIndex = 47;
            this.label_Cur.Text = "--";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 12);
            this.label5.TabIndex = 35;
            this.label5.Text = "Battery Status:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(285, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 12);
            this.label10.TabIndex = 40;
            this.label10.Text = "Design Capacity:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(285, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 12);
            this.label15.TabIndex = 45;
            this.label15.Text = "Voltage:";
            // 
            // label_DC
            // 
            this.label_DC.AutoSize = true;
            this.label_DC.Location = new System.Drawing.Point(418, 87);
            this.label_DC.Name = "label_DC";
            this.label_DC.Size = new System.Drawing.Size(13, 12);
            this.label_DC.TabIndex = 42;
            this.label_DC.Text = "--";
            // 
            // label_Vol
            // 
            this.label_Vol.AutoSize = true;
            this.label_Vol.Location = new System.Drawing.Point(418, 30);
            this.label_Vol.Name = "label_Vol";
            this.label_Vol.Size = new System.Drawing.Size(13, 12);
            this.label_Vol.TabIndex = 44;
            this.label_Vol.Text = "--";
            // 
            // label_Temp
            // 
            this.label_Temp.AutoSize = true;
            this.label_Temp.Location = new System.Drawing.Point(418, 160);
            this.label_Temp.Name = "label_Temp";
            this.label_Temp.Size = new System.Drawing.Size(13, 12);
            this.label_Temp.TabIndex = 43;
            this.label_Temp.Text = "--";
            // 
            // timer_SBS
            // 
            this.timer_SBS.Enabled = true;
            this.timer_SBS.Interval = 30000;
            this.timer_SBS.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // ctlMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Name = "ctlMain";
            this.Size = new System.Drawing.Size(544, 425);
            this.Load += new System.EventHandler(this.Main_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label_SN;
        private System.Windows.Forms.Label label_DV;
        private System.Windows.Forms.Label label_MD;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label_ASC;
        private System.Windows.Forms.Label label_CC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_RSC;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_FCC;
        private System.Windows.Forms.Label label_BS;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label_Cur;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label_DC;
        private System.Windows.Forms.Label label_Vol;
        private System.Windows.Forms.Label label_Temp;
        private System.Windows.Forms.Timer timer_SBS;
        private System.Windows.Forms.Label label_Manu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_SoH;
        private System.Windows.Forms.Label label_ATTE_text;
        private System.Windows.Forms.Label label_ATTE;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_RC;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label_ATTF;
        private System.Windows.Forms.Label label_EC;
        private System.Windows.Forms.Label label14;
    }
}

